import { and, eq, gt } from "drizzle-orm";
import { getDb } from "@/db";
import { chatSessions, chatUsers } from "@/db/schema";

export const SESSION_COOKIE = "yappertron_session";
export const SESSION_AGE_SECONDS = 30 * 24 * 60 * 60;
export const SESSION_ONLY_AGE_SECONDS = 12 * 60 * 60;
// Cloudflare Workers WebCrypto rejects PBKDF2 iteration counts above 100,000.
const PASSWORD_ITERATIONS = 100_000;

export type ChatAccount = { id: number; username: string };

export function randomHex(byteCount: number) {
  const bytes = crypto.getRandomValues(new Uint8Array(byteCount));
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function sha256(value: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function derivePasswordHash(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: new TextEncoder().encode(salt), iterations: PASSWORD_ITERATIONS, hash: "SHA-256" }, key, 256);
  return Array.from(new Uint8Array(bits), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function constantTimeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let mismatch = 0;
  for (let index = 0; index < left.length; index += 1) mismatch |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return mismatch === 0;
}

export function readSessionToken(request: Request) {
  const cookie = request.headers.get("Cookie") ?? "";
  for (const part of cookie.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === SESSION_COOKIE) return value.join("=");
  }
  return null;
}

export function sessionCookie(token: string, maxAgeSeconds?: number) {
  const maxAge = maxAgeSeconds === undefined ? "" : `; Max-Age=${maxAgeSeconds}`;
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax${maxAge}`;
}

export async function createSession(userId: number, maxAgeSeconds = SESSION_AGE_SECONDS) {
  const token = randomHex(32);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + maxAgeSeconds * 1000);
  await getDb().insert(chatSessions).values({ tokenHash: await sha256(token), userId, createdAt: now, expiresAt });
  return token;
}

export async function destroySession(request: Request) {
  const token = readSessionToken(request);
  if (!token) return;
  await getDb().delete(chatSessions).where(eq(chatSessions.tokenHash, await sha256(token)));
}

export async function getChatAccount(request: Request): Promise<ChatAccount | null> {
  const token = readSessionToken(request);
  if (!token) return null;
  const [row] = await getDb().select({ id: chatUsers.id, username: chatUsers.username })
    .from(chatSessions)
    .innerJoin(chatUsers, eq(chatSessions.userId, chatUsers.id))
    .where(and(eq(chatSessions.tokenHash, await sha256(token)), gt(chatSessions.expiresAt, new Date())))
    .limit(1);
  return row ?? null;
}
