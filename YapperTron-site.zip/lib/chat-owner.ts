export async function hashChatOwnerToken(token: unknown): Promise<string | null> {
  if (typeof token !== "string" || !/^[a-f0-9]{64}$/i.test(token)) return null;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
}
