import { integer, primaryKey, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const chatUsers = sqliteTable("chat_users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull(),
  usernameKey: text("username_key").notNull(),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  avatarUrl: text("avatar_url"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (table) => [uniqueIndex("chat_users_username_key_unique").on(table.usernameKey)]);

export const chatProfiles = sqliteTable("chat_profiles", {
  userId: integer("user_id").primaryKey().references(() => chatUsers.id, { onDelete: "cascade" }),
  displayName: text("display_name"),
  bio: text("bio").notNull().default(""),
  themeColor: text("theme_color").notNull().default("#d52f40"),
});

export const chatProfilePosts = sqliteTable("chat_profile_posts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => chatUsers.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const chatSessions = sqliteTable("chat_sessions", {
  tokenHash: text("token_hash").primaryKey(),
  userId: integer("user_id").notNull().references(() => chatUsers.id, { onDelete: "cascade" }),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
});

export const chatAuthAttempts = sqliteTable("chat_auth_attempts", {
  attemptKey: text("attempt_key").primaryKey(),
  attempts: integer("attempts").notNull(),
  windowStartedAt: integer("window_started_at", { mode: "timestamp_ms" }).notNull(),
});

export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  text: text("text").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  replyTo: integer("reply_to"),
  ownerUserId: integer("owner_user_id").references(() => chatUsers.id, { onDelete: "set null" }),
  ownerTokenHash: text("owner_token_hash"),
  edited: integer("edited", { mode: "boolean" }).notNull().default(false),
  deleted: integer("deleted", { mode: "boolean" }).notNull().default(false),
});

export const messageReactions = sqliteTable("message_reactions", {
  messageId: integer("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  nameKey: text("name_key").notNull(),
  name: text("name").notNull(),
  emoji: text("emoji").notNull(),
}, (table) => [primaryKey({ columns: [table.messageId, table.nameKey, table.emoji] })]);

export const members = sqliteTable("chat_members", {
  nameKey: text("name_key").primaryKey(),
  name: text("name").notNull(),
  lastSeen: integer("last_seen", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});
