CREATE TABLE `chat_members` (
	`name_key` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`last_seen` integer NOT NULL
);
