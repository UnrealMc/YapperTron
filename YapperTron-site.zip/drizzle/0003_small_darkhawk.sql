ALTER TABLE `messages` ADD `owner_token_hash` text;--> statement-breakpoint
ALTER TABLE `messages` ADD `edited` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `messages` ADD `deleted` integer DEFAULT false NOT NULL;