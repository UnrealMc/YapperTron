ALTER TABLE `chat_users` ADD `avatar_url` text;
