CREATE TABLE `message_reactions` (
	`message_id` integer NOT NULL,
	`name_key` text NOT NULL,
	`name` text NOT NULL,
	`emoji` text NOT NULL,
	PRIMARY KEY(`message_id`, `name_key`, `emoji`),
	FOREIGN KEY (`message_id`) REFERENCES `messages`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
ALTER TABLE `messages` ADD `reply_to` integer;