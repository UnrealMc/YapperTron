"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type KeyboardEvent } from "react";

type AccountSuggestion = { username: string; avatarUrl: string | null };

export default function AccountSearch() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<AccountSuggestion[]>([]);
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const value = query.trim();
    if (!value) { setResults([]); setOpen(false); return; }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      try {
        const response = await fetch(`/api/accounts/search?q=${encodeURIComponent(value)}`, { cache: "no-store", signal: controller.signal });
        const data = await response.json() as { accounts?: AccountSuggestion[] };
        if (!controller.signal.aborted) { setResults(data.accounts ?? []); setActive(0); setOpen(true); }
      } catch { /* Keep typing responsive if search briefly fails. */ }
    }, 180);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [query]);

  function visit(account: AccountSuggestion) {
    setOpen(false);
    setQuery("");
    router.push(`/u/${encodeURIComponent(account.username)}`);
  }

  function handleKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "ArrowDown" && results.length) {
      event.preventDefault(); setOpen(true); setActive((index) => (index + 1) % results.length);
    } else if (event.key === "ArrowUp" && results.length) {
      event.preventDefault(); setOpen(true); setActive((index) => (index - 1 + results.length) % results.length);
    } else if (event.key === "Tab" && results.length) {
      event.preventDefault();
      const selected = results[active] ?? results[0];
      setQuery(selected.username); setActive(results.indexOf(selected)); setOpen(true);
    } else if (event.key === "Enter") {
      const exact = results.find((item) => item.username.toLocaleLowerCase() === query.trim().toLocaleLowerCase());
      const selected = exact ?? results[active];
      if (selected) { event.preventDefault(); visit(selected); }
    } else if (event.key === "Escape") setOpen(false);
  }

  return <div className="account-search">
    <label className="account-search-box">
      <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4 4"/></svg>
      <input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} onFocus={() => { if (query) setOpen(true); }} onBlur={() => window.setTimeout(() => setOpen(false), 120)} onKeyDown={handleKeyDown} autoComplete="off" placeholder="Search accounts" aria-label="Search user accounts" aria-expanded={open && results.length > 0} aria-controls="account-search-results" role="combobox" aria-autocomplete="list" />
      {query && <button type="button" className="account-search-clear" aria-label="Clear search" onClick={() => { setQuery(""); inputRef.current?.focus(); }}><svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 4 8 8M12 4l-8 8" /></svg></button>}
    </label>
    {open && query.trim() && <div className="account-search-results" id="account-search-results" role="listbox" aria-label="Matching accounts">
      {results.length ? <>
        {results.map((account, index) => <button type="button" role="option" aria-selected={index === active} className={`account-search-result${index === active ? " active" : ""}`} key={account.username} onMouseDown={(event) => event.preventDefault()} onMouseEnter={() => setActive(index)} onClick={() => visit(account)}>
          <img src={account.avatarUrl || "/yappertron-logo.png"} alt="" />
          <span><strong>{account.username}</strong><small>View profile</small></span>
          <kbd>↵</kbd>
        </button>)}
        <div className="account-search-hint">↑ ↓ move · Tab complete · Enter view</div>
      </> : <div className="account-search-empty">No matching accounts</div>}
    </div>}
  </div>;
}
