"use client";

import AccountSearch from "@/app/components/account-search";
import { useEffect, useState, type CSSProperties, type FormEvent } from "react";

type Profile = { id: number; username: string; displayName: string; avatarUrl: string | null; bio: string; themeColor: string };
type ProfilePost = { id: number; text: string; createdAt: string };

export default function ProfilePage({ username }: { username: string }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [posts, setPosts] = useState<ProfilePost[]>([]);
  const [myUsername, setMyUsername] = useState("");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [themeColor, setThemeColor] = useState("#d52f40");
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const ownProfile = Boolean(profile && myUsername && profile.username.toLowerCase() === myUsername.toLowerCase());

  async function load() {
    setLoading(true); setError("");
    try {
      const [profileResponse, accountResponse] = await Promise.all([
        fetch(`/api/profile/${encodeURIComponent(username)}`, { cache: "no-store" }),
        fetch("/api/auth/me", { cache: "no-store" }),
      ]);
      const profileData = await profileResponse.json() as { profile?: Profile; posts?: ProfilePost[]; error?: string };
      if (!profileResponse.ok || !profileData.profile) throw new Error(profileData.error || "Could not load this profile.");
      const accountData = await accountResponse.json() as { user?: { username?: string } | null };
      setProfile(profileData.profile); setPosts(profileData.posts ?? []); setMyUsername(accountData.user?.username ?? "");
      setDisplayName(profileData.profile.displayName === profileData.profile.username ? "" : profileData.profile.displayName);
      setBio(profileData.profile.bio ?? ""); setThemeColor(profileData.profile.themeColor || "#d52f40");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not load this profile."); }
    finally { setLoading(false); }
  }

  useEffect(() => { void load(); }, [username]);

  async function saveProfile(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch(`/api/profile/${encodeURIComponent(username)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ displayName, bio, themeColor }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "Could not save your profile.");
      setEditing(false); await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Could not save your profile."); }
    finally { setBusy(false); }
  }

  async function createPost(event: FormEvent) {
    event.preventDefault(); if (!draft.trim()) return;
    setBusy(true); setError("");
    try {
      const response = await fetch(`/api/profile/${encodeURIComponent(username)}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: draft }) });
      const data = await response.json() as { post?: ProfilePost; error?: string };
      if (!response.ok || !data.post) throw new Error(data.error || "Could not publish your post.");
      setPosts((current) => [data.post!, ...current]); setDraft("");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not publish your post."); }
    finally { setBusy(false); }
  }

  return <main className="profile-page" style={{ "--profile-accent": profile?.themeColor || "#d52f40" } as CSSProperties}>
    <header className="profile-topbar">
      <a className="profile-brand" href="/"><img src="/yappertron-logo.png" alt="" /><strong>YapperTron</strong></a>
      <AccountSearch />
      <a className="profile-back" href="/">← Back to chat</a>
    </header>
    <div className="profile-content">
      {loading ? <p className="profile-loading">Loading profile…</p> : error && !profile ? <section className="profile-error-card"><h1>Profile unavailable</h1><p>{error}</p><a href="/">Return to YapperTron</a></section> : profile && <>
        <section className="profile-hero">
          <div className="profile-cover" />
          <img className="profile-large-avatar" src={profile.avatarUrl || "/yappertron-logo.png"} alt={`${profile.username}'s profile picture`} />
          <div className="profile-heading"><div><h1>{profile.displayName}</h1><p>@{profile.username}</p></div>
            {ownProfile && <button className="profile-edit-button" type="button" onClick={() => setEditing((value) => !value)}>{editing ? "Cancel edit" : "Edit profile"}</button>}
          </div>
          {profile.bio && <p className="profile-bio">{profile.bio}</p>}
        </section>
        {editing && ownProfile && <form className="profile-editor" onSubmit={saveProfile}>
          <h2>Customize your account</h2>
          <label>Display name<input maxLength={30} value={displayName} onChange={(event) => setDisplayName(event.target.value)} placeholder={profile.username} /></label>
          <label>About you<textarea maxLength={180} rows={3} value={bio} onChange={(event) => setBio(event.target.value)} placeholder="A little about yourself…" /></label>
          <label className="profile-color-label">Profile color<input type="color" value={themeColor} onChange={(event) => setThemeColor(event.target.value)} /></label>
          <div className="profile-editor-footer"><small>{bio.length}/180</small><button type="submit" disabled={busy}>{busy ? "Saving…" : "Save profile"}</button></div>
        </form>}
        <section className="profile-post-section"><div className="profile-post-heading"><h2>Posts</h2><span>{posts.length}</span></div>
          {ownProfile && <form className="profile-post-form" onSubmit={createPost}><img src={profile.avatarUrl || "/yappertron-logo.png"} alt="" /><textarea aria-label="Write a profile post" maxLength={500} rows={3} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Share something with your profile…" /><button type="submit" disabled={busy || !draft.trim()}>{busy ? "Posting…" : "Post"}</button></form>}
          {error && profile && <p className="profile-inline-error" role="alert">{error}</p>}
          {posts.length ? <div className="profile-post-list">{posts.map((post) => <article className="profile-post" key={post.id}><div className="profile-post-meta"><img src={profile.avatarUrl || "/yappertron-logo.png"} alt="" /><strong>{profile.displayName}</strong><time dateTime={post.createdAt}>{new Date(post.createdAt).toLocaleString()}</time></div><p>{post.text}</p></article>)}</div> : <div className="profile-empty-posts">{ownProfile ? "Your posts will show up here." : "No posts yet."}</div>}
        </section>
      </>}
    </div>
  </main>;
}
