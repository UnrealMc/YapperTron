"use client";

import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import AccountSearch from "@/app/components/account-search";

type MessageReaction = { emoji: string; names: string[]; mine?: boolean };
type ReplyPreview = { id: number; name: string; text: string };
type ChatMessage = {
  id: number;
  name: string;
  avatarUrl?: string | null;
  text: string;
  createdAt: string;
  replyTo: number | null;
  reply: ReplyPreview | null;
  reactions: MessageReaction[];
  isMine: boolean;
  edited: boolean;
  deleted: boolean;
};
type Member = { name: string; online: boolean; avatarUrl: string | null };
type ChatAccount = { id: number; username: string; avatarUrl: string | null };
type PickerMode = "emoji" | "sticker" | "gif" | null;
type GifItem = { title: string; tags: string; url: string };
const KLIPY_API_KEY = "gZhnfn7OyUQyFmyV1m5JeCPEQvDkDpg0xf3eORew51wp8Sod5lLkwyz9GeTzmWO3";
const EMOJIS: Array<{ emoji: string; name: string }> = [
  { emoji: "😀", name: "grinning happy face" }, { emoji: "😄", name: "smiling happy face" }, { emoji: "😂", name: "laughing tears" }, { emoji: "🤣", name: "rolling laughing" },
  { emoji: "😊", name: "smiling blush" }, { emoji: "😍", name: "heart eyes love" }, { emoji: "🥰", name: "smiling hearts love" }, { emoji: "😘", name: "kiss love" },
  { emoji: "😎", name: "cool sunglasses" }, { emoji: "😭", name: "crying tears" }, { emoji: "🥺", name: "pleading please" }, { emoji: "😡", name: "angry mad" },
  { emoji: "🤔", name: "thinking hmm" }, { emoji: "🙄", name: "eye roll" }, { emoji: "😴", name: "sleepy tired" }, { emoji: "🤯", name: "mind blown shocked" },
  { emoji: "👍", name: "thumbs up yes" }, { emoji: "👎", name: "thumbs down no" }, { emoji: "👏", name: "clapping applause" }, { emoji: "🙌", name: "hands celebration" },
  { emoji: "🙏", name: "praying thanks" }, { emoji: "👀", name: "eyes look" }, { emoji: "🔥", name: "fire hot" }, { emoji: "✨", name: "sparkles" },
  { emoji: "🎉", name: "party celebration" }, { emoji: "❤️", name: "red heart love" }, { emoji: "💀", name: "skull dead" }, { emoji: "💯", name: "hundred perfect" },
  { emoji: "🤝", name: "handshake deal" }, { emoji: "💖", name: "sparkling heart love" }, { emoji: "🥳", name: "party face" }, { emoji: "😱", name: "screaming surprised" },
  { emoji: "🙂", name: "slight smile" }, { emoji: "😉", name: "wink" }, { emoji: "😋", name: "silly tasty" }, { emoji: "😆", name: "laughing grin" },
  { emoji: "😅", name: "nervous laugh sweat" }, { emoji: "🥲", name: "smile tear" }, { emoji: "😇", name: "angel halo" }, { emoji: "🤩", name: "star struck" },
  { emoji: "😏", name: "smirk" }, { emoji: "😬", name: "grimace awkward" }, { emoji: "🫡", name: "salute" }, { emoji: "🤗", name: "hug" },
  { emoji: "🤫", name: "shushing quiet" }, { emoji: "🤭", name: "giggle hand over mouth" }, { emoji: "🫠", name: "melting" }, { emoji: "🥱", name: "yawning" },
  { emoji: "😤", name: "huff determined" }, { emoji: "😈", name: "devil mischievous" }, { emoji: "👻", name: "ghost spooky" }, { emoji: "🤖", name: "robot" },
  { emoji: "💃", name: "dancing woman" }, { emoji: "🕺", name: "dancing man" }, { emoji: "🙋", name: "raising hand" }, { emoji: "🤷", name: "shrug" },
  { emoji: "💪", name: "strong muscle" }, { emoji: "✌️", name: "peace sign" }, { emoji: "🤌", name: "pinched fingers" }, { emoji: "🫶", name: "heart hands" },
  { emoji: "🤞", name: "fingers crossed" }, { emoji: "🫰", name: "finger heart" }, { emoji: "🤟", name: "love you hand" }, { emoji: "👋", name: "waving hello" },
  { emoji: "🐶", name: "dog puppy" }, { emoji: "🐱", name: "cat face" }, { emoji: "🐸", name: "frog" }, { emoji: "🐼", name: "panda" },
  { emoji: "🦊", name: "fox" }, { emoji: "🐻", name: "bear" }, { emoji: "🐨", name: "koala" }, { emoji: "🐵", name: "monkey" },
  { emoji: "🦄", name: "unicorn" }, { emoji: "🐧", name: "penguin" }, { emoji: "🦋", name: "butterfly" }, { emoji: "🐢", name: "turtle" },
  { emoji: "🍕", name: "pizza food" }, { emoji: "🍔", name: "burger food" }, { emoji: "🍟", name: "fries food" }, { emoji: "🍩", name: "donut food" },
  { emoji: "🍪", name: "cookie food" }, { emoji: "🍰", name: "cake dessert" }, { emoji: "🍓", name: "strawberry fruit" }, { emoji: "🍉", name: "watermelon fruit" },
  { emoji: "☕", name: "coffee" }, { emoji: "🧋", name: "bubble tea" }, { emoji: "🥤", name: "drink" }, { emoji: "🍿", name: "popcorn" },
  { emoji: "⚽", name: "football soccer" }, { emoji: "🏀", name: "basketball" }, { emoji: "🎮", name: "video game controller" }, { emoji: "🎧", name: "headphones music" },
  { emoji: "🎸", name: "guitar music" }, { emoji: "🏆", name: "trophy winner" }, { emoji: "🚀", name: "rocket launch" }, { emoji: "🌈", name: "rainbow" },
  { emoji: "☀️", name: "sun sunny" }, { emoji: "🌙", name: "moon night" }, { emoji: "💫", name: "dizzy stars" }, { emoji: "⚡", name: "lightning bolt" },
  { emoji: "💌", name: "love letter" }, { emoji: "💘", name: "heart arrow" }, { emoji: "💔", name: "broken heart" }, { emoji: "🧡", name: "orange heart" },
  { emoji: "💛", name: "yellow heart" }, { emoji: "💚", name: "green heart" }, { emoji: "💙", name: "blue heart" }, { emoji: "💜", name: "purple heart" },
  { emoji: "🤍", name: "white heart" }, { emoji: "🖤", name: "black heart" }, { emoji: "❣️", name: "heart exclamation" }, { emoji: "💤", name: "sleep zzz" },
  { emoji: "✅", name: "check mark yes" }, { emoji: "❌", name: "cross no" }, { emoji: "⭐", name: "star favorite" }, { emoji: "💎", name: "diamond gem" },
];
const STICKERS = ["Laughing koala", "Wave cat", "Surprised frog", "Happy bird", "Thumbs-up koala", "Sleepy cat", "Cheering frog", "Laughing bird"];
const QUICK_REACTIONS = ["✅", "🎉", "❌"];
const GIFS = [
  { title: "Hello wave", tags: "hello hi wave greeting happy", url: "https://static2.klipy.com/ii/c44064a00e4b7451969381d90dea1769/12/6d/Y7hEdhed.gif" },
  { title: "Hi there", tags: "hello hi greeting avatar", url: "https://static2.klipy.com/ii/a8ada81afc59159ea5c8927feffa2e31/1b/80/bebf8f9sTb5Jg.gif" },
  { title: "Thinking cat", tags: "thinking cat confused hmm", url: "https://static2.klipy.com/ii/2711dd8a75a85be822d136ec94899b3f/5b/d4/uVpG4Mxf.gif" },
  { title: "Laughing", tags: "lol laughing funny happy", url: "https://static2.klipy.com/ii/4e7bea9f7a3371424e6c16ebc93252fe/37/b1/FDm70HzysvY3SaTDEpFu.gif" },
  { title: "Love", tags: "love heart romance", url: "https://static2.klipy.com/ii/e293a233a303a98e471f78d04e13a1b0/c9/02/e6FpCl9T.gif" },
  { title: "Happy birthday", tags: "happy birthday party cake", url: "https://static2.klipy.com/ii/d7aec6f6f171607374b2065c836f92f4/07/40/aDf1WrH4.gif" },
  { title: "Hello", tags: "hello wave greeting", url: "https://static.klipy.com/ii/d7aec6f6f171607374b2065c836f92f4/ec/f3/OXB1QWhn.gif" },
];

function stickerPosition(index: number) {
  return `${(index % 4) * (100 / 3)}% ${Math.floor(index / 4) * 100}%`;
}

let pingAudioContext: AudioContext | null = null;

function unlockPingAudio() {
  if (typeof window === "undefined" || !window.AudioContext) return;
  pingAudioContext ??= new window.AudioContext();
  if (pingAudioContext.state === "suspended") void pingAudioContext.resume();
}

function playPingSound() {
  const context = pingAudioContext;
  if (!context || context.state !== "running") return;
  const start = context.currentTime;
  [880, 1175].forEach((frequency, index) => {
    const time = start + index * 0.11;
    const oscillator = context.createOscillator();
    const volume = context.createGain();
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(frequency, time);
    volume.gain.setValueAtTime(0.0001, time);
    volume.gain.exponentialRampToValueAtTime(0.16, time + 0.012);
    volume.gain.exponentialRampToValueAtTime(0.0001, time + 0.12);
    oscillator.connect(volume);
    volume.connect(context.destination);
    oscillator.start(time);
    oscillator.stop(time + 0.13);
  });
}

function containsMention(text: string, target: string) {
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`@${escaped}(?=$|[\\s.,!?])`, "i").test(text);
}

function mentionContext(value: string, caret: number) {
  const before = value.slice(0, caret);
  const match = /(?:^|\s)@([^\s@]*)$/.exec(before);
  if (!match) return null;
  return { start: before.length - match[1].length - 1, query: match[1] };
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isEmojiOnly(text: string) {
  const value = text.trim().replace(/\s+/g, "");
  if (!value || /^(FILE\||GIF\||STICKER\|)/.test(value)) return false;
  return /^(?:(?:\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\p{Emoji_Modifier})?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\p{Emoji_Modifier})?)*)|(?:[\u{1F1E6}-\u{1F1FF}]{2})|(?:[#*0-9]\uFE0F?\u20E3))+$/u.test(value);
}

function renderMentions(text: string, members: Member[]) {
  const names = members.map((member) => member.name).filter(Boolean).sort((a, b) => b.length - a.length);
  if (names.length === 0) return text;
  const pattern = new RegExp(`@(${names.map(escapeRegExp).join("|")})(?=$|[\\s.,!?])`, "gi");
  const result: ReactNode[] = [];
  let cursor = 0;
  for (const match of text.matchAll(pattern)) {
    const index = match.index ?? 0;
    result.push(text.slice(cursor, index));
    result.push(<span className="mention-highlight" key={`${index}-${match[0]}`}>{match[0]}</span>);
    cursor = index + match[0].length;
  }
  result.push(text.slice(cursor));
  return result;
}

function renderInlineFormatting(text: string, members: Member[]) {
  const pattern = /(\*\*[^*\n]+\*\*|\*[^*\n]+\*|__[^_\n]+__|~~[^~\n]+~~|\|\|[^|\n]+\|\||`[^`\n]+`)/g;
  const result: ReactNode[] = [];
  let cursor = 0;
  for (const match of text.matchAll(pattern)) {
    const index = match.index ?? 0;
    result.push(renderMentions(text.slice(cursor, index), members));
    const token = match[0];
    const content = token.slice(token.startsWith("**") || token.startsWith("__") || token.startsWith("||") ? 2 : 1, -(token.startsWith("**") || token.startsWith("__") || token.startsWith("||") ? 2 : 1));
    const key = `format-${index}`;
    if (token.startsWith("**")) result.push(<strong key={key}>{renderMentions(content, members)}</strong>);
    else if (token.startsWith("__")) result.push(<u key={key}>{renderMentions(content, members)}</u>);
    else if (token.startsWith("~~")) result.push(<s key={key}>{renderMentions(content, members)}</s>);
    else if (token.startsWith("||")) result.push(<span className="message-spoiler" key={key} tabIndex={0}>{renderMentions(content, members)}</span>);
    else if (token.startsWith("`")) result.push(<code className="message-code" key={key}>{content}</code>);
    else result.push(<em key={key}>{renderMentions(content, members)}</em>);
    cursor = index + token.length;
  }
  result.push(renderMentions(text.slice(cursor), members));
  return result;
}

function renderFormattedMessage(text: string, members: Member[]) {
  return text.split("\n").map((line, index) => {
    if (line.startsWith("> ")) return <blockquote className="message-quote" key={`quote-${index}`}>{renderInlineFormatting(line.slice(2), members)}</blockquote>;
    return <div className="formatted-line" key={`line-${index}`}>{renderInlineFormatting(line, members)}</div>;
  });
}

function isGifUrl(value: string) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && (url.pathname.toLowerCase().endsWith(".gif") || url.searchParams.get("format") === "gif");
  } catch { return false; }
}

function messagePreviewText(text: string) {
  if (text.startsWith("FILE|")) {
    try {
      const file = JSON.parse(text.slice(5)) as { name?: unknown };
      return `📎 ${typeof file.name === "string" ? file.name : "File"}`;
    } catch { return "📎 File"; }
  }
  if (text.startsWith("GIF|")) return "GIF";
  if (text.startsWith("STICKER|")) return "Sticker";
  return text.length > 120 ? `${text.slice(0, 117)}…` : text;
}

function cropAvatarImage(source: string, zoom: number, position: { x: number; y: number }) {
  return new Promise<string>((resolve, reject) => {
    const image = new Image();
    image.onload = () => {
      const side = 192;
      const canvas = document.createElement("canvas");
      canvas.width = side;
      canvas.height = side;
      const context = canvas.getContext("2d");
      if (!context) return reject(new Error("Image editor is unavailable."));
      const fitSide = Math.min(image.naturalWidth, image.naturalHeight);
      const crop = fitSide * 0.9 / zoom;
      const centerX = image.naturalWidth / 2 + (position.x - 0.5) * fitSide / zoom;
      const centerY = image.naturalHeight / 2 + (position.y - 0.5) * fitSide / zoom;
      const left = centerX - crop / 2;
      const top = centerY - crop / 2;
      context.drawImage(image, left, top, crop, crop, 0, 0, side, side);
      resolve(canvas.toDataURL("image/webp", 0.84));
    };
    image.onerror = () => reject(new Error("That image could not be opened."));
    image.src = source;
  });
}

function getOrCreateChatOwnerToken() {
  const key = "yappertron-owner-token";
  const existing = window.localStorage.getItem(key);
  if (existing && /^[a-f0-9]{64}$/i.test(existing)) return existing;
  const bytes = new Uint8Array(32);
  window.crypto.getRandomValues(bytes);
  const token = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  window.localStorage.setItem(key, token);
  return token;
}

function renderMessageContent(text: string, members: Member[]) {
  if (text.startsWith("FILE|")) {
    try {
      const file = JSON.parse(text.slice(5)) as { name: string; type: string; size?: number; dataUrl: string };
      if (typeof file.name === "string" && typeof file.type === "string" && typeof file.dataUrl === "string" && file.dataUrl.startsWith(`data:${file.type};base64,`)) {
        return <span className="shared-file">
          {file.type.startsWith("image/") && <img className="shared-file-preview" src={file.dataUrl} alt={file.name} loading="lazy" />}
          <a href={file.dataUrl} download={file.name} rel="noreferrer">{file.name}</a>
          {typeof file.size === "number" && <small>{Math.max(1, Math.round(file.size / 1024))} KB</small>}
        </span>;
      }
    } catch { return <span className="media-unavailable">File unavailable</span>; }
    return <span className="media-unavailable">File unavailable</span>;
  }
  if (text.startsWith("STICKER|")) {
    const value = text.slice(8);
    const index = Number(value);
    if (Number.isInteger(index) && index >= 0 && index < STICKERS.length) {
      return <span className="sticker-image" role="img" aria-label={STICKERS[index]} style={{ backgroundPosition: stickerPosition(index) }} />;
    }
    return <span className="sticker-image legacy-sticker" aria-label="Sticker">{value}</span>;
  }
  if (text.startsWith("GIF|")) {
    const url = text.slice(4);
    return isGifUrl(url)
      ? <img className="chat-gif" src={url} alt="GIF" loading="lazy" referrerPolicy="no-referrer" />
      : <span className="media-unavailable">GIF unavailable</span>;
  }
  return renderFormattedMessage(text, members);
}

export default function Home() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [joined, setJoined] = useState(false);
  const [account, setAccount] = useState<ChatAccount | null>(null);
  const [avatarPickerOpen, setAvatarPickerOpen] = useState(false);
  const [avatarEditorImage, setAvatarEditorImage] = useState<string | null>(null);
  const [avatarZoom, setAvatarZoom] = useState(1);
  const [avatarCropPosition, setAvatarCropPosition] = useState({ x: 0.5, y: 0.5 });
  const [avatarError, setAvatarError] = useState("");
  const [avatarBusy, setAvatarBusy] = useState(false);
  const [recentAvatarUploads, setRecentAvatarUploads] = useState<string[]>([]);
  const [authReady, setAuthReady] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authUsername, setAuthUsername] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [authError, setAuthError] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [ownerToken, setOwnerToken] = useState("");
  const [text, setText] = useState("");
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null);
  const [editDraft, setEditDraft] = useState("");
  const [composerSelection, setComposerSelection] = useState<{ start: number; end: number } | null>(null);
  const [replyTarget, setReplyTarget] = useState<ChatMessage | null>(null);
  const [reactionPickerFor, setReactionPickerFor] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [selectedMention, setSelectedMention] = useState(0);
  const [picker, setPicker] = useState<PickerMode>(null);
  const [pickerSearch, setPickerSearch] = useState("");
  const [gifCategory, setGifCategory] = useState<string | null>(null);
  const [gifResults, setGifResults] = useState<GifItem[]>(GIFS);
  const [gifLoading, setGifLoading] = useState(false);
  const [gifError, setGifError] = useState("");
  const [favoriteGifs, setFavoriteGifs] = useState<string[]>([]);
  const [uploadingFile, setUploadingFile] = useState(false);
  const listRef = useRef<HTMLOListElement>(null);
  const composerRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarUploadRef = useRef<HTMLInputElement>(null);
  const avatarCropDragging = useRef(false);
  const latestId = useRef(0);
  const polling = useRef(false);

  useEffect(() => {
    try { setFavoriteGifs(JSON.parse(window.localStorage.getItem("chat-favorite-gifs") ?? "[]") as string[]); } catch { setFavoriteGifs([]); }
  }, []);

  useEffect(() => {
    try { setOwnerToken(getOrCreateChatOwnerToken()); } catch { setError("This browser can’t save an owner key for your messages."); }
  }, []);

  useEffect(() => {
    if (!account) {
      setRecentAvatarUploads([]);
      return;
    }
    const key = `yappertron-recent-avatars:${account.username.toLocaleLowerCase("en-US")}`;
    try {
      const stored = JSON.parse(window.localStorage.getItem(key) ?? "[]");
      setRecentAvatarUploads(Array.isArray(stored) ? stored.filter((value): value is string => typeof value === "string" && value.startsWith("data:image/" )).slice(0, 6) : []);
    } catch { setRecentAvatarUploads([]); }
  }, [account?.username]);

  useEffect(() => {
    let active = true;
    const loadAccount = async () => {
      try {
        const response = await fetch("/api/auth/me", { cache: "no-store" });
        const data = await response.json() as { user: ChatAccount | null };
        if (!active) return;
        setAccount(data.user);
        if (data.user) {
          setName(data.user.username);
          setJoined(true);
        }
      } catch {
        if (active) setAuthError("Could not load your account. Refresh and try again.");
      } finally {
        if (active) setAuthReady(true);
      }
    };
    void loadAccount();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (picker !== "gif") return;
    const query = pickerSearch.trim();
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setGifLoading(true);
      setGifError("");
      try {
        const endpoint = query ? "search" : "trending";
        const url = new URL(`https://api.klipy.com/api/v1/${encodeURIComponent(KLIPY_API_KEY)}/gifs/${endpoint}`);
        url.searchParams.set("page", "1");
        url.searchParams.set("per_page", "24");
        url.searchParams.set("locale", "en_GB");
        url.searchParams.set("country", "GB");
        url.searchParams.set("contentfilter", "high");
        if (query) url.searchParams.set("q", query);
        const response = await fetch(url, { signal: controller.signal, cache: "no-store" });
        if (!response.ok) throw new Error("GIF search isn’t available right now.");
        const payload = await response.json() as { results?: unknown; data?: unknown; items?: unknown };
        const candidate = payload.results ?? payload.data ?? payload.items;
        const rawItems = Array.isArray(candidate) ? candidate : candidate && typeof candidate === "object"
          ? Object.values(candidate as Record<string, unknown>).find(Array.isArray) ?? []
          : [];
        const items = rawItems.flatMap((rawItem): GifItem[] => {
          if (!rawItem || typeof rawItem !== "object") return [];
          const item = rawItem as Record<string, unknown>;
          const formats = item.media_formats as Record<string, { url?: string }> | undefined;
          const files = item.file as Record<string, Record<string, string | { url?: string }>> | undefined;
          const smallGif = files?.sm?.gif;
          const mediumGif = files?.md?.gif;
          const largeGif = files?.hd?.gif;
          const imageUrl = (typeof smallGif === "string" ? smallGif : smallGif?.url) ?? (typeof mediumGif === "string" ? mediumGif : mediumGif?.url) ?? (typeof largeGif === "string" ? largeGif : largeGif?.url) ?? formats?.gif?.url ?? formats?.mediumgif?.url ?? (typeof item.url === "string" ? item.url : "");
          if (!isGifUrl(imageUrl)) return [];
          const tags = Array.isArray(item.tags) ? item.tags.filter((tag): tag is string => typeof tag === "string").join(" ") : "";
          return [{ title: typeof item.title === "string" && item.title ? item.title : "GIF", tags, url: imageUrl }];
        });
        setGifResults(items);
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setGifError(error instanceof Error ? error.message : "GIF search isn’t available right now.");
        setGifResults(GIFS);
      } finally {
        if (!controller.signal.aborted) setGifLoading(false);
      }
    }, query ? 350 : 0);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [picker, pickerSearch]);

  function toggleGifFavorite(url: string) {
    setFavoriteGifs((current) => {
      const next = current.includes(url) ? current.filter((item) => item !== url) : [...current, url];
      window.localStorage.setItem("chat-favorite-gifs", JSON.stringify(next));
      return next;
    });
  }

  function openAvatarPicker() {
    setAvatarPickerOpen(true);
    setAvatarEditorImage(null);
    setAvatarZoom(1);
    setAvatarCropPosition({ x: 0.5, y: 0.5 });
    setAvatarError("");
  }

  function moveAvatarCrop(event: ReactPointerEvent<HTMLDivElement>) {
    if (!avatarCropDragging.current) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const radius = 0.38;
    const x = Math.max(radius, Math.min(1 - radius, (event.clientX - rect.left) / rect.width));
    const y = Math.max(radius, Math.min(1 - radius, (event.clientY - rect.top) / rect.height));
    setAvatarCropPosition({ x, y });
  }

  function startAvatarCropDrag(event: ReactPointerEvent<HTMLDivElement>) {
    event.preventDefault();
    avatarCropDragging.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    moveAvatarCrop(event);
  }

  function stopAvatarCropDrag() {
    avatarCropDragging.current = false;
  }

  function handleAvatarFile(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) {
      setAvatarError("Choose an image smaller than 5 MB.");
      input.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") {
        setAvatarError("That image could not be opened.");
        return;
      }
      setAvatarEditorImage(reader.result);
      setAvatarZoom(1);
      setAvatarCropPosition({ x: 0.5, y: 0.5 });
      setAvatarError("");
    };
    reader.onerror = () => setAvatarError("That image could not be opened.");
    reader.readAsDataURL(file);
    input.value = "";
  }

  async function saveAvatar(avatarUrl: string | null) {
    if (!account) return;
    setAvatarBusy(true);
    setAvatarError("");
    try {
      const response = await fetch("/api/profile/avatar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl }),
      });
      const result = await response.json() as { user?: ChatAccount; error?: string };
      if (!response.ok || !result.user) throw new Error(result.error ?? "Profile picture could not be saved.");
      setAccount(result.user);
      setMessages((current) => current.map((message) => message.name.toLocaleLowerCase("en-US") === account.username.toLocaleLowerCase("en-US")
        ? { ...message, avatarUrl }
        : message));
      setMembers((current) => current.map((member) => member.name.toLocaleLowerCase("en-US") === account.username.toLocaleLowerCase("en-US")
        ? { ...member, avatarUrl }
        : member));
      if (avatarUrl) {
        const nextRecent = [avatarUrl, ...recentAvatarUploads.filter((item) => item !== avatarUrl)].slice(0, 6);
        setRecentAvatarUploads(nextRecent);
        window.localStorage.setItem(`yappertron-recent-avatars:${account.username.toLocaleLowerCase("en-US")}`, JSON.stringify(nextRecent));
      }
      setAvatarPickerOpen(false);
      setAvatarEditorImage(null);
    } catch (error) {
      setAvatarError(error instanceof Error ? error.message : "Profile picture could not be saved. Try again.");
    } finally {
      setAvatarBusy(false);
    }
  }

  async function applyAvatarEdit() {
    if (!avatarEditorImage) return;
    setAvatarBusy(true);
    setAvatarError("");
    try {
      const cropped = await cropAvatarImage(avatarEditorImage, avatarZoom, avatarCropPosition);
      await saveAvatar(cropped);
    } catch (error) {
      setAvatarError(error instanceof Error ? error.message : "That image could not be edited.");
      setAvatarBusy(false);
    }
  }

  async function submitAccountAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAuthBusy(true);
    setAuthError("");
    try {
      const response = await fetch(authMode === "signup" ? "/api/auth/register" : "/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: authUsername.trim(), password: authPassword, rememberMe }),
      });
      const result = await response.json() as { user?: ChatAccount; error?: string };
      if (!response.ok || !result.user) throw new Error(result.error ?? "Could not sign in. Try again.");
      setAccount(result.user);
      setName(result.user.username);
      setJoined(true);
      setAuthPassword("");
      unlockPingAudio();
    } catch (error) {
      setAuthError(error instanceof Error ? error.message : "Could not sign in. Try again.");
    } finally {
      setAuthBusy(false);
    }
  }

  async function logOut() {
    setAuthBusy(true);
    try {
      const response = await fetch("/api/auth/logout", { method: "POST" });
      if (!response.ok) throw new Error("Could not sign out. Try again.");
      setAccount(null);
      setJoined(false);
      setName("");
      setMessages([]);
      latestId.current = 0;
      setAuthError("");
    } catch {
      setAuthError("Could not sign out. Try again.");
    } finally {
      setAuthBusy(false);
    }
  }

  const receiveMessages = useCallback(async (initial = false) => {
    if (polling.current) return;
    polling.current = true;
    try {
      const suffix = initial ? "" : `?after=${latestId.current}`;
      const response = await fetch(`/api/messages${suffix}`, {
        headers: ownerToken ? { "X-Chat-Owner-Token": ownerToken } : undefined,
        cache: "no-store",
      });
      if (!response.ok) throw new Error("Could not connect to chat.");
      const data = (await response.json()) as {
        messages: ChatMessage[];
        reactionSnapshot?: Record<string, MessageReaction[]>;
        editedSnapshot?: Array<{ id: number; text: string; edited: boolean }>;
        deletedMessageIds?: number[];
      };
      if (!initial && data.messages.some((message) => message.name !== name && containsMention(message.text, name))) {
        playPingSound();
      }
      setMessages((current) => {
        const merged = new Map<number, ChatMessage>();
        for (const message of current) merged.set(message.id, message);
        let changed = false;
        for (const message of data.messages) {
          if (!merged.has(message.id)) {
            merged.set(message.id, message);
            changed = true;
          }
        }
        for (const edited of data.editedSnapshot ?? []) {
          const message = merged.get(edited.id);
          if (message && (message.text !== edited.text || message.edited !== edited.edited)) {
            merged.set(edited.id, { ...message, text: edited.text, edited: edited.edited });
            changed = true;
          }
        }
        for (const [messageId, reactions] of Object.entries(data.reactionSnapshot ?? {})) {
          const id = Number(messageId);
          const message = merged.get(id);
          if (message && JSON.stringify(message.reactions ?? []) !== JSON.stringify(reactions)) {
            merged.set(id, { ...message, reactions });
            changed = true;
          }
        }
        for (const deletedId of data.deletedMessageIds ?? []) {
          if (merged.delete(deletedId)) changed = true;
        }
        if (!changed) return current;
        const next = Array.from(merged.values()).sort((a, b) => a.id - b.id);
        if (next.length) latestId.current = Math.max(latestId.current, next[next.length - 1].id);
        return next.slice(-200);
      });
      setConnected(true);
      setError("");
    } catch {
      setConnected(false);
      setError("Can’t connect right now. Please try again.");
    } finally {
      polling.current = false;
    }
  }, [name, ownerToken]);

  const refreshMembers = useCallback(async () => {
    try {
      const response = await fetch("/api/presence", { cache: "no-store" });
      if (!response.ok) return;
      const data = (await response.json()) as { members: Member[] };
      setMembers(data.members);
      const avatars = new Map(data.members.map((member) => [member.name.toLocaleLowerCase("en-US"), member.avatarUrl]));
      setMessages((current) => {
        let changed = false;
        const next = current.map((message) => {
          const avatarUrl = avatars.get(message.name.toLocaleLowerCase("en-US")) ?? null;
          if ((message.avatarUrl ?? null) === avatarUrl) return message;
          changed = true;
          return { ...message, avatarUrl };
        });
        return changed ? next : current;
      });
    } catch { /* Keep the last member list visible during brief network interruptions. */ }
  }, []);

  useEffect(() => {
    if (!joined) return;
    let alive = true;
    const poll = async (initial = false) => {
      if (alive && !document.hidden) await receiveMessages(initial);
    };
    const refreshOnReturn = () => {
      if (!document.hidden) {
        void poll();
        void refreshMembers();
      }
    };
    void poll(true);
    const timer = window.setInterval(() => void poll(), 2500);
    const sendHeartbeat = async () => {
      try {
        await fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name }),
        });
      } catch { /* Presence refreshes on the next heartbeat. */ }
    };
    void sendHeartbeat();
    void refreshMembers();
    const heartbeatTimer = window.setInterval(() => { if (!document.hidden) void sendHeartbeat(); }, 20_000);
    const memberTimer = window.setInterval(() => { if (!document.hidden) void refreshMembers(); }, 20_000);
    document.addEventListener("visibilitychange", refreshOnReturn);
    return () => {
      alive = false;
      window.clearInterval(timer);
      window.clearInterval(heartbeatTimer);
      window.clearInterval(memberTimer);
      document.removeEventListener("visibilitychange", refreshOnReturn);
    };
  }, [joined, name, receiveMessages, refreshMembers]);

  useEffect(() => {
    const list = listRef.current;
    if (list) list.scrollTop = list.scrollHeight;
  }, [messages]);

  async function sendContent(message: string, clearDraft = true) {
    if (!message) return false;
    if (!ownerToken) {
      setError("Chat is still setting up your message key. Try again in a moment.");
      return false;
    }
    setError("");
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, text: message, replyTo: replyTarget?.id ?? null, ownerToken }),
      });
      if (!response.ok) throw new Error("Could not send.");
      if (clearDraft) setText("");
      setReplyTarget(null);
      setPicker(null);
      setReactionPickerFor(null);
      await receiveMessages();
      return true;
    } catch {
      setError("Message didn’t send. Try again.");
      return false;
    }
  }

  async function uploadFile(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    if (file.size > 256 * 1024) {
      setError("Choose a file smaller than 256 KB.");
      input.value = "";
      return;
    }
    setUploadingFile(true);
    setError("");
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Could not read file."));
        reader.onerror = () => reject(new Error("Could not read file."));
        reader.readAsDataURL(file);
      });
      const type = file.type || "application/octet-stream";
      const safeName = file.name.replace(/[\\/]/g, "_").slice(0, 180) || "shared-file";
      const sent = await sendContent(`FILE|${JSON.stringify({ name: safeName, type, size: file.size, dataUrl })}`, false);
      if (sent) input.value = "";
    } catch {
      setError("That file couldn’t be read. Try another one.");
    } finally {
      setUploadingFile(false);
    }
  }

  async function send(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (editingMessage) {
      await saveEditedMessage();
      return;
    }
    await sendContent(text.trim());
  }

  function startEditingMessage(message: ChatMessage) {
    if (!message.isMine || /^(FILE\||GIF\||STICKER\|)/.test(message.text)) return;
    setEditingMessage(message);
    setEditDraft(message.text);
    setReplyTarget(null);
    setPicker(null);
    setReactionPickerFor(null);
    setMentionQuery(null);
    window.requestAnimationFrame(() => composerRef.current?.focus());
  }

  async function saveEditedMessage() {
    if (!editingMessage || !editDraft.trim() || !ownerToken) return;
    setError("");
    try {
      const response = await fetch("/api/messages/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "edit", messageId: editingMessage.id, text: editDraft, ownerToken }),
      });
      if (!response.ok) throw new Error("Message could not be edited.");
      setMessages((current) => current.map((message) => message.id === editingMessage.id
        ? { ...message, text: editDraft.trim(), edited: true }
        : message));
      setEditingMessage(null);
      setEditDraft("");
      await receiveMessages();
    } catch {
      setError("Message couldn’t be edited. Try again.");
    }
  }

  async function deleteOwnMessage(message: ChatMessage) {
    if (!message.isMine || !ownerToken) return;
    setError("");
    try {
      const response = await fetch("/api/messages/actions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete", messageId: message.id, ownerToken }),
      });
      if (!response.ok) {
        const result = await response.json().catch(() => null) as { error?: string } | null;
        throw new Error(result?.error ?? "Message could not be deleted.");
      }
      setMessages((current) => current.filter((item) => item.id !== message.id));
      setReplyTarget((current) => current?.id === message.id ? null : current);
      await receiveMessages();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Message couldn’t be deleted. Try again.");
    }
  }

  function cancelEditingMessage() {
    setEditingMessage(null);
    setEditDraft("");
  }

  async function toggleReaction(messageId: number, emoji: string) {
    setError("");
    try {
      const response = await fetch("/api/reactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageId, name, emoji, ownerToken }),
      });
      if (!response.ok) {
        const result = await response.json().catch(() => null) as { error?: string } | null;
        throw new Error(result?.error ?? "Reaction could not be saved.");
      }
      const result = await response.json() as { active: boolean; name: string };
      setMessages((current) => current.map((message) => {
        if (message.id !== messageId) return message;
        const reactions = [...message.reactions];
        const index = reactions.findIndex((reaction) => reaction.emoji === emoji);
        if (result.active) {
          if (index < 0) reactions.push({ emoji, names: [name], mine: true });
          else {
            const reaction = reactions[index];
            reactions[index] = { ...reaction, names: reaction.names.includes(name) ? reaction.names : [...reaction.names, name], mine: true };
          }
        } else if (index >= 0) {
          const reaction = reactions[index];
          const names = reaction.names.filter((reactor) => reactor !== result.name);
          if (!names.length) reactions.splice(index, 1);
          else reactions[index] = { ...reaction, names, mine: false };
        }
        return { ...message, reactions };
      }));
      setReactionPickerFor(null);
      await receiveMessages();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Reaction didn’t save. Try again.");
    }
  }

  function replyToMessage(message: ChatMessage) {
    cancelEditingMessage();
    setReplyTarget(message);
    setReactionPickerFor(null);
    setPicker(null);
    window.requestAnimationFrame(() => composerRef.current?.focus());
  }

  function forwardMessage(message: ChatMessage) {
    cancelEditingMessage();
    setReplyTarget(null);
    setReactionPickerFor(null);
    setText(`↪ Forwarded from ${message.name}: ${messagePreviewText(message.text)}`);
    window.requestAnimationFrame(() => composerRef.current?.focus());
  }

  function updateComposerSelection() {
    const input = composerRef.current;
    if (!input) return;
    const start = input.selectionStart ?? 0;
    const end = input.selectionEnd ?? start;
    setComposerSelection(end > start ? { start, end } : null);
  }

  function applyComposerFormat(kind: "bold" | "italic" | "underline" | "strike" | "quote" | "code" | "spoiler") {
    const input = composerRef.current;
    const value = editingMessage ? editDraft : text;
    const start = input?.selectionStart ?? composerSelection?.start ?? 0;
    const end = input?.selectionEnd ?? composerSelection?.end ?? start;
    if (end <= start) return;
    let formatStart = start;
    let formatEnd = end;
    if (kind === "quote") {
      formatStart = value.lastIndexOf("\n", start - 1) + 1;
      const nextLineBreak = value.indexOf("\n", end);
      formatEnd = nextLineBreak === -1 ? value.length : nextLineBreak;
    }
    const selected = value.slice(formatStart, formatEnd);
    const wrappers: Record<typeof kind, [string, string]> = {
      bold: ["**", "**"], italic: ["*", "*"], underline: ["__", "__"],
      strike: ["~~", "~~"], quote: ["> ", ""], code: ["`", "`"], spoiler: ["||", "||"],
    };
    const [opening, closing] = wrappers[kind];
    const formatted = kind === "quote" ? selected.split("\n").map((line) => `> ${line}`).join("\n") : `${opening}${selected}${closing}`;
    const next = `${value.slice(0, formatStart)}${formatted}${value.slice(formatEnd)}`;
    if (next.length > 1000) {
      setError("Formatting would make this message longer than 1,000 characters.");
      return;
    }
    if (editingMessage) setEditDraft(next);
    else setText(next);
    setError("");
    setMentionQuery(null);
    setComposerSelection(null);
    window.requestAnimationFrame(() => {
      input?.focus();
      input?.setSelectionRange(formatStart + opening.length, formatStart + opening.length + selected.length);
      updateComposerSelection();
    });
  }

  function insertEmoji(emoji: string) {
    const input = composerRef.current;
    const caret = input?.selectionStart ?? text.length;
    const next = `${text.slice(0, caret)}${emoji}${text.slice(caret)}`;
    setText(next);
    setPicker(null);
    window.requestAnimationFrame(() => {
      input?.focus();
      input?.setSelectionRange(caret + emoji.length, caret + emoji.length);
    });
  }

  function togglePicker(mode: Exclude<PickerMode, null>) {
    setPicker((current) => current === mode ? null : mode);
    setReactionPickerFor(null);
    setPickerSearch("");
    setGifCategory(null);
    setMentionQuery(null);
  }

  const mentionOptions = mentionQuery === null ? [] : members
    .filter((member) => member.name.toLowerCase().includes(mentionQuery.toLowerCase()))
    .slice(0, 8);
  const visibleEmojis = EMOJIS.filter((item) => `${item.emoji} ${item.name}`.toLowerCase().includes(pickerSearch.toLowerCase()));
  const visibleStickers = STICKERS.map((name, index) => ({ name, index })).filter((item) => item.name.toLowerCase().includes(pickerSearch.toLowerCase()));
  const visibleGifs = gifResults.filter((gif) => {
    const matchesSearch = !pickerSearch.trim() || (!gifLoading && !gifError ? true : `${gif.title} ${gif.tags}`.toLowerCase().includes(pickerSearch.toLowerCase()));
    const matchesCategory = !gifCategory || gifCategory === "trending" || (gifCategory === "favorites" ? favoriteGifs.includes(gif.url) : gif.tags.toLowerCase().includes(gifCategory));
    return matchesSearch && matchesCategory;
  });

  function chooseMention(member: Member) {
    const input = composerRef.current;
    if (!input) return;
    const caret = input.selectionStart ?? text.length;
    const context = mentionContext(text, caret);
    if (!context) return;
    const cursor = context.start + member.name.length + 2;
    const next = `${text.slice(0, context.start)}@${member.name} ${text.slice(caret)}`;
    setText(next);
    setMentionQuery(null);
    window.requestAnimationFrame(() => {
      input.focus();
      input.setSelectionRange(cursor, cursor);
    });
  }

  function handleComposerKeyDown(event: KeyboardEvent<HTMLInputElement>) {
    if (mentionOptions.length === 0) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setSelectedMention((current) => (current + 1) % mentionOptions.length);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setSelectedMention((current) => (current - 1 + mentionOptions.length) % mentionOptions.length);
    } else if (event.key === "Tab" || event.key === "Enter") {
      event.preventDefault();
      chooseMention(mentionOptions[selectedMention] ?? mentionOptions[0]);
    } else if (event.key === "Escape") {
      setMentionQuery(null);
    }
  }

  if (!authReady) return <main className="chat-shell"><div className="auth-loading">Loading YapperTron…</div></main>;

  if (!account) {
    return <main className="chat-shell auth-page">
      <section className="auth-card" aria-label="YapperTron sign in">
        <img className="brand-logo" src="/yappertron-logo.png" alt="YapperTron koala logo" />
        <h1>{authMode === "login" ? "Log in to YapperTron" : "Create your account"}</h1>
        <p>Use a username and password to join the chat.</p>
        <form className="auth-form" onSubmit={submitAccountAuth}>
          <label htmlFor="auth-username">Username</label>
          <input id="auth-username" type="text" autoComplete="username" minLength={3} maxLength={20} pattern="[A-Za-z0-9_.-]{3,20}" required value={authUsername} onChange={(event) => setAuthUsername(event.target.value)} disabled={authBusy} />
          <label htmlFor="auth-password">Password</label>
          <input id="auth-password" type="password" autoComplete={authMode === "signup" ? "new-password" : "current-password"} minLength={8} maxLength={128} required value={authPassword} onChange={(event) => setAuthPassword(event.target.value)} disabled={authBusy} />
          <label className="remember-option" htmlFor="remember-me"><input id="remember-me" type="checkbox" checked={rememberMe} onChange={(event) => setRememberMe(event.target.checked)} disabled={authBusy} /> Remember me on this device</label>
          {authMode === "signup" && <small className="auth-hint">Username: 3–20 letters, numbers, dots, dashes, or underscores. Password: at least 8 characters.</small>}
          {authError && <p className="auth-error" role="alert">{authError}</p>}
          <button className="auth-submit" type="submit" disabled={authBusy}>{authBusy ? "Please wait…" : authMode === "login" ? "Log in" : "Sign up"}</button>
        </form>
        <button className="auth-mode-toggle" type="button" disabled={authBusy} onClick={() => { setAuthMode((mode) => mode === "login" ? "signup" : "login"); setAuthError(""); }}>{authMode === "login" ? "New to YapperTron? Sign up" : "Already have an account? Log in"}</button>
      </section>
    </main>;
  }

  return (
    <main className="chat-shell">
      {!joined ? <div className="auth-loading">Opening your chat…</div> : (
        <div className="chat-layout">
          <section className="chat" aria-label="Chat">
            <header className="chat-header">
              <div className="chat-brand"><img className="brand-logo-small" src="/yappertron-logo.png" alt="" /><div><h1>YapperTron</h1><p>Talking as <strong>{name}</strong></p></div></div>
              <AccountSearch />
              <div className="chat-header-actions"><button className="my-profile-button" type="button" onClick={() => router.push(`/u/${encodeURIComponent(name)}`)}>My profile</button><button className="switch-account" type="button" disabled={authBusy} onClick={() => void logOut()}>Log out</button></div>
            </header>
            <ol className="messages" ref={listRef} aria-live="polite">
              {messages.length === 0 && <li className="empty">{connected ? "No messages yet" : "Connecting…"}</li>}
              {messages.map((message) => (
                <li className="message" key={message.id}>
                  <div className="message-actions" aria-label={`Actions for ${message.name}'s message`}>
                    {QUICK_REACTIONS.map((emoji) => {
                      const reacted = message.reactions.some((reaction) => reaction.emoji === emoji && (reaction.mine || reaction.names.some((reactor) => reactor.toLocaleLowerCase() === name.toLocaleLowerCase())));
                      const label = reacted ? `Remove your ${emoji} reaction` : `React with ${emoji}`;
                      return <button key={emoji} type="button" className={reacted ? "reaction-action-active" : ""} title={label} data-tooltip={label} aria-label={label} onClick={() => void toggleReaction(message.id, emoji)}>{emoji}</button>;
                    })}
                    <button type="button" title="Add Reaction" data-tooltip="Add reaction" aria-label="Add Reaction" onClick={() => setReactionPickerFor((current) => current === message.id ? null : message.id)}><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c.9 1.4 2.1 2.1 3.5 2.1s2.6-.7 3.5-2.1M8.5 9.5h.01M15.5 9.5h.01"/></svg></button>
                    <button type="button" title="Reply" data-tooltip="Reply" aria-label="Reply" onClick={() => replyToMessage(message)}>↩</button>
                    <button className="forward-action" type="button" title="Forward" aria-label="Forward" data-tooltip="Forward" onClick={() => forwardMessage(message)}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 14 5-5-5-5M20 9h-6a6 6 0 0 0-6 6v5"/></svg></button>
                    {message.isMine && !/^(FILE\||GIF\||STICKER\|)/.test(message.text) && <button type="button" title="Edit message" data-tooltip="Edit message" aria-label="Edit message" onClick={() => startEditingMessage(message)}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 16.5-.8 4.3 4.3-.8L19.7 7.8a2.1 2.1 0 0 0-3-3L4 16.5Z"/><path d="m14.9 6.6 3 3"/></svg></button>}
                    {message.isMine && <button className="message-delete" type="button" title="Delete message" data-tooltip="Delete message" aria-label="Delete message" onClick={() => void deleteOwnMessage(message)}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m3 0-.8 13H6.8L6 7m4 4v5m4-5v5"/></svg></button>}
                  </div>
                  {reactionPickerFor === message.id && <div className="reaction-picker" aria-label="Choose a reaction">
                    <div className="reaction-picker-grid">{EMOJIS.map(({ emoji, name: emojiName }) => <button key={emoji} type="button" title={emojiName} aria-label={`React with ${emojiName}`} onClick={() => void toggleReaction(message.id, emoji)}>{emoji}</button>)}</div>
                  </div>}
                  <div className="message-meta">
                    <img className="message-avatar" src={message.avatarUrl || "/yappertron-logo.png"} alt="" loading="lazy" />
                    <span className="sender">{message.name}</span>
                    <time className="timestamp" dateTime={message.createdAt}>
                      {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}
                    </time>
                    {message.edited && <span className="edited-note">edited</span>}
                  </div>
                  {message.reply && <div className="reply-quote"><strong>Replying to {message.reply.name}</strong><span>{messagePreviewText(message.reply.text)}</span></div>}
                  <div className={`body${isEmojiOnly(message.text) ? " emoji-only" : ""}`}>{renderMessageContent(message.text, members)}</div>
                  {message.reactions.length > 0 && <div className="reaction-list" aria-label="Reactions">
                    {message.reactions.map(({ emoji, names }) => {
                      const mine = message.reactions.find((reaction) => reaction.emoji === emoji)?.mine || names.some((reactor) => reactor.toLocaleLowerCase() === name.toLocaleLowerCase());
                      return <button key={emoji} type="button" className={`reaction-chip${mine ? " mine" : ""}`} title={mine ? `Remove your ${emoji} reaction` : `Add a ${emoji} reaction`} aria-label={`${mine ? "Remove your" : "Add a"} ${emoji} reaction; ${names.length} total`} aria-pressed={mine} onClick={() => void toggleReaction(message.id, emoji)}><span>{emoji}</span><span>{names.length}</span></button>;
                    })}
                  </div>}
                </li>
              ))}
            </ol>
            <div className="composer-wrap">
              {editingMessage && <div className="edit-composer">
                <div><strong>Editing your message</strong><span>{messagePreviewText(editingMessage.text)}</span></div>
                <button type="button" title="Cancel edit" aria-label="Cancel edit" onClick={cancelEditingMessage}>×</button>
              </div>}
              {replyTarget && <div className="reply-composer">
                <div><strong>Replying to {replyTarget.name}</strong><span>{messagePreviewText(replyTarget.text)}</span></div>
                <button type="button" title="Cancel reply" aria-label="Cancel reply" onClick={() => setReplyTarget(null)}>×</button>
              </div>}
              {composerSelection && <div className="composer-format-toolbar" role="toolbar" aria-label="Format selected text">
                <button type="button" title="Bold" aria-label="Bold" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("bold")}><strong>B</strong></button>
                <button type="button" title="Italic" aria-label="Italic" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("italic")}><em>I</em></button>
                <button type="button" title="Underline" aria-label="Underline" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("underline")}><u>U</u></button>
                <button type="button" title="Strikethrough" aria-label="Strikethrough" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("strike")}><s>S</s></button>
                <span className="format-toolbar-divider" aria-hidden="true" />
                <button type="button" title="Quote" aria-label="Quote" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("quote")}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 11H5a3 3 0 0 0-3 3v5h7v-5a3 3 0 0 1 3-3Zm12 0h-5a3 3 0 0 0-3 3v5h7v-5a3 3 0 0 1 3-3ZM5 11c0-4 2-6 5-7m7 7c0-4 2-6 5-7"/></svg></button>
                <button type="button" title="Code" aria-label="Code" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("code")}><span className="format-code-icon">&lt;&gt;</span></button>
                <button type="button" title="Spoiler" aria-label="Spoiler" onMouseDown={(event) => event.preventDefault()} onClick={() => applyComposerFormat("spoiler")}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.2-6 9.5-6 9.5 6 9.5 6-3.2 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></svg></button>
              </div>}
              {picker && (
                <div className="media-picker" aria-label={`${picker} picker`}>
                  <div className="picker-tabs" role="tablist" aria-label="Choose media type">
                    {([ ["gif", "GIFs"], ["sticker", "Stickers"], ["emoji", "Emoji"] ] as const).map(([mode, label]) => <button key={mode} type="button" role="tab" aria-selected={picker === mode} className={picker === mode ? "active" : ""} onClick={() => { setPicker(mode); setPickerSearch(""); setGifCategory(null); }}>{label}</button>)}
                  </div>
                  <label className="picker-search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4 4"/></svg><input aria-label={picker === "gif" ? "Search Klipy GIFs" : picker === "emoji" ? "Search emoji" : "Search stickers"} placeholder={picker === "gif" ? "Search KLIPY" : picker === "emoji" ? "Search emoji" : "Search stickers"} value={pickerSearch} onChange={(event) => { setPickerSearch(event.target.value); setGifCategory(null); }} /></label>
                  {picker === "emoji" && <div className="emoji-panel">
                    {!pickerSearch && <><div className="picker-section-title">★ &nbsp;Favorites</div><div className="emoji-grid emoji-favorites">{["😂", "❤️", "👍", "🎉"].map((emoji) => <button key={emoji} type="button" aria-label={`Insert ${emoji}`} onClick={() => insertEmoji(emoji)}>{emoji}</button>)}</div><div className="picker-section-title">◷ &nbsp;Frequently Used</div></>}
                    <div className="emoji-grid">{visibleEmojis.map(({ emoji, name }) => <button key={emoji} type="button" aria-label={`Insert ${name}`} title={name} onClick={() => insertEmoji(emoji)}>{emoji}</button>)}</div>
                  </div>}
                  {picker === "sticker" && <div className="sticker-grid">
                    {visibleStickers.map(({ name, index }) => <button key={name} type="button" aria-label={`Send ${name} sticker`} onClick={() => void sendContent(`STICKER|${index}`, false)}><span className="sticker-thumb" aria-hidden="true" style={{ backgroundPosition: stickerPosition(index) }} /></button>)}
                  </div>}
                  {picker === "gif" && <div className="gif-picker">
                    {!pickerSearch && gifCategory === null ? <div className="gif-categories">
                      {[
                        { title: "Favorites", category: "favorites", url: GIFS.find((gif) => favoriteGifs.includes(gif.url))?.url ?? GIFS[0].url },
                        { title: "Trending GIFs", category: "trending", url: GIFS[3].url },
                        { title: "hello", category: "hello", url: GIFS[0].url },
                        { title: "lol", category: "lol", url: GIFS[3].url },
                        { title: "love", category: "love", url: GIFS[4].url },
                        { title: "happy birthday", category: "birthday", url: GIFS[5].url },
                      ].map((category) => <button key={category.category} type="button" className="gif-category-card" onClick={() => setGifCategory(category.category)}><img src={category.url} alt="" loading="lazy" /><span>{category.title}</span></button>)}
                    </div> : <div className="gif-results">
                      {visibleGifs.map((gif) => <div className="gif-result" key={gif.url}>
                        <button type="button" className="gif-pick" aria-label={`Send ${gif.title} GIF`} onClick={() => void sendContent(`GIF|${gif.url}`, false)}><img src={gif.url} alt={gif.title} loading="lazy" /><span>{gif.title}</span></button>
                        <button type="button" className={`gif-favorite${favoriteGifs.includes(gif.url) ? " saved" : ""}`} aria-label={`${favoriteGifs.includes(gif.url) ? "Remove from" : "Add to"} favorites`} onClick={() => toggleGifFavorite(gif.url)}>{favoriteGifs.includes(gif.url) ? "★" : "☆"}</button>
                      </div>)}
                      {gifLoading && <p className="gif-empty">Loading GIFs…</p>}
                      {!gifLoading && gifError && <p className="gif-empty">{gifError}</p>}
                      {!gifLoading && !gifError && visibleGifs.length === 0 && <p className="gif-empty">No matches. Try another search.</p>}
                    </div>}
                    <div className="klipy-credit">Powered by KLIPY</div>
                  </div>}
                </div>
              )}
              {mentionOptions.length > 0 && (
                <div className="mention-picker" role="listbox" aria-label="People to ping">
                  {mentionOptions.map((member, index) => (
                    <button
                      className={`mention-option${index === selectedMention ? " selected" : ""}`}
                      key={member.name.toLowerCase()}
                      onMouseDown={(event) => event.preventDefault()}
                      onClick={() => chooseMention(member)}
                      role="option"
                      aria-selected={index === selectedMention}
                      type="button"
                    >
                      <span className={`member-dot ${member.online ? "online" : "offline"}`} />
                      {member.name}
                      {!member.online && <small>offline</small>}
                    </button>
                  ))}
                </div>
              )}
              <div className="composer-row">
              <form className="composer" onSubmit={send}>
                <input ref={fileInputRef} className="file-input" type="file" aria-label="Choose a file to upload" onChange={uploadFile} />
                <button className="composer-add" type="button" title="Add attachment" aria-label="Add attachment" disabled={uploadingFile || Boolean(editingMessage)} onClick={() => fileInputRef.current?.click()} />
                <input
                  ref={composerRef}
                  aria-label={editingMessage ? "Edit message" : "Message"}
                  autoComplete="off"
                  maxLength={1000}
                  onChange={(event) => {
                    if (editingMessage) {
                      setEditDraft(event.target.value);
                      return;
                    }
                    setText(event.target.value);
                    const context = mentionContext(event.target.value, event.target.selectionStart ?? event.target.value.length);
                    setMentionQuery(context?.query ?? null);
                    setSelectedMention(0);
                  }}
                  onKeyDown={handleComposerKeyDown}
                  onKeyUp={updateComposerSelection}
                  onMouseUp={updateComposerSelection}
                  onSelect={updateComposerSelection}
                  placeholder={editingMessage ? "Edit message" : "Message"}
                  value={editingMessage ? editDraft : text}
                />
                <div className="media-toolbar">
                  <button type="button" title="GIFs" aria-label="GIFs" disabled={Boolean(editingMessage)} onClick={() => togglePicker("gif")}>GIF</button>
                  <button type="button" title="Stickers" aria-label="Stickers" disabled={Boolean(editingMessage)} onClick={() => togglePicker("sticker")}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 3.75h10l4 4V16a5 5 0 0 1-5 5H5a2 2 0 0 1-2-2V5.75a2 2 0 0 1 2-2Z"/><path d="M15 3.75v4h4M8 12h.01M15 12h.01M8.5 15.5c1.9 1.8 4.9 1.8 6.8 0"/></svg></button>
                  <button type="button" title="Emoji" aria-label="Emoji" disabled={Boolean(editingMessage)} onClick={() => togglePicker("emoji")}><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M8.5 14.5c.9 1.4 2.1 2.1 3.5 2.1s2.6-.7 3.5-2.1M8.5 9.5h.01M15.5 9.5h.01"/></svg></button>
                </div>
                <button className="composer-send" type="submit" title={editingMessage ? "Save changes" : "Post"} aria-label={editingMessage ? "Save changes" : "Post"}>{editingMessage ? "Save" : "Post"}</button>
              </form>
              <div className="composer-profile" aria-label={`Signed in as ${name}`} title={`${name} · Online`}>
                <button
                  className="composer-avatar-button"
                  type="button"
                  title="Change profile picture — click or right-click"
                  aria-label="Change profile picture"
                  onClick={openAvatarPicker}
                  onContextMenu={(event) => { event.preventDefault(); openAvatarPicker(); }}
                >
                  <img className="composer-avatar" src={account?.avatarUrl || "/yappertron-logo.png"} alt="" />
                </button>
                <span className="composer-profile-copy"><strong>{name}</strong><small><i />Online</small></span>
              </div>
              </div>
            </div>
            <div className="status" role="status">{error}</div>
          </section>
          <aside className="member-sidebar" aria-label="Players">
            <section className="member-group">
              <h2>ONLINE — {members.filter((member) => member.online).length}</h2>
              {members.filter((member) => member.online).map((member) => (
                <button type="button" className="member-row member-row-button" key={member.name.toLowerCase()} onClick={() => router.push(`/u/${encodeURIComponent(member.name)}`)} title={`View ${member.name}'s profile`}>
                  <img className="member-avatar" src={member.avatarUrl || "/yappertron-logo.png"} alt="" loading="lazy" />
                  <span className="member-dot online" />
                  <span className="member-name">{member.name}</span>
                </button>
              ))}
            </section>
            <section className="member-group">
              <h2>OFFLINE — {members.filter((member) => !member.online).length}</h2>
              {members.filter((member) => !member.online).map((member) => (
                <button type="button" className="member-row member-row-button" key={member.name.toLowerCase()} onClick={() => router.push(`/u/${encodeURIComponent(member.name)}`)} title={`View ${member.name}'s profile`}>
                  <img className="member-avatar" src={member.avatarUrl || "/yappertron-logo.png"} alt="" loading="lazy" />
                  <span className="member-dot offline" />
                  <span className="member-name">{member.name}</span>
                </button>
              ))}
            </section>
          </aside>
        </div>
      )}
      {joined && avatarPickerOpen && (
        <div className="avatar-dialog-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget && !avatarBusy) setAvatarPickerOpen(false); }}>
          <section className="avatar-dialog" role="dialog" aria-modal="true" aria-labelledby="avatar-dialog-title">
            <header className="avatar-dialog-header">
              <h2 id="avatar-dialog-title">{avatarEditorImage ? "Edit image" : "Select an image"}</h2>
              <button type="button" className="avatar-dialog-close" aria-label="Close" disabled={avatarBusy} onClick={() => setAvatarPickerOpen(false)}>×</button>
            </header>
            {!avatarEditorImage ? <>
              <input ref={avatarUploadRef} className="file-input" type="file" accept="image/*" aria-label="Upload profile picture" onChange={handleAvatarFile} />
              <div className="avatar-select-grid">
                <button className="avatar-upload-tile" type="button" onClick={() => avatarUploadRef.current?.click()}>
                  <span className="avatar-upload-icon" aria-hidden="true">＋</span>
                  <strong>Upload image</strong>
                  <small>PNG, JPG, or WebP · max 5 MB</small>
                </button>
                <button className="avatar-logo-choice" type="button" onClick={() => void saveAvatar(null)} disabled={avatarBusy}>
                  <img src="/yappertron-logo.png" alt="" />
                  <span>Use YapperTron logo</span>
                </button>
              </div>
              {recentAvatarUploads.length > 0 && <div className="avatar-recents">
                <h3>Recent avatars</h3>
                <div>{recentAvatarUploads.map((avatar, index) => <button type="button" key={`${index}-${avatar.slice(-20)}`} title={`Edit recent avatar ${index + 1}`} onClick={() => { setAvatarEditorImage(avatar); setAvatarZoom(1); setAvatarError(""); }}><img src={avatar} alt={`Recent avatar ${index + 1}`} /></button>)}</div>
              </div>}
            </> : <>
                <div
                  className="avatar-crop-stage"
                  onPointerDown={startAvatarCropDrag}
                  onPointerMove={moveAvatarCrop}
                  onPointerUp={stopAvatarCropDrag}
                  onPointerCancel={stopAvatarCropDrag}
                  aria-label="Drag the circle to choose what appears in your profile picture"
                >
                  <img src={avatarEditorImage} alt="Profile picture preview" style={{ transform: `scale(${avatarZoom})` }} />
                  <div className="avatar-crop-circle" style={{ left: `${avatarCropPosition.x * 100}%`, top: `${avatarCropPosition.y * 100}%` }} aria-hidden="true" />
                </div>
                <p className="avatar-crop-hint">Drag the circle to choose what appears in your picture.</p>
              <label className="avatar-zoom-control" htmlFor="avatar-zoom"><span>Image size</span><input id="avatar-zoom" type="range" min="1" max="3" step="0.05" value={avatarZoom} onChange={(event) => setAvatarZoom(Number(event.target.value))} /><b aria-hidden="true">＋</b></label>
              <div className="avatar-edit-actions">
                <button type="button" className="avatar-reset" onClick={() => { setAvatarZoom(1); setAvatarCropPosition({ x: 0.5, y: 0.5 }); }}>Reset</button>
                <span />
                <button type="button" className="avatar-cancel" onClick={() => { setAvatarEditorImage(null); setAvatarZoom(1); setAvatarCropPosition({ x: 0.5, y: 0.5 }); }}>Cancel</button>
                <button type="button" className="avatar-apply" disabled={avatarBusy} onClick={() => void applyAvatarEdit()}>{avatarBusy ? "Saving…" : "Apply"}</button>
              </div>
            </>}
            {avatarError && <p className="avatar-error" role="alert">{avatarError}</p>}
          </section>
        </div>
      )}
    </main>
  );
}
