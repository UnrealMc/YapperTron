import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "YapperTron",
  description: "A friendly place to chat and yap together.",
  icons: { icon: "/yappertron-logo.png" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
