import ProfilePage from "@/app/components/profile-page";

export default async function UserProfile({ params }: { params: Promise<{ username: string }> }) {
  const { username } = await params;
  return <ProfilePage username={username} />;
}
