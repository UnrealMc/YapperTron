import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { chatUsers } from "@/db/schema";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const MAX_AVATAR_LENGTH = 150_000;
const AVATAR_DATA_URL = /^data:image\/(?:webp|png|jpeg);base64,[A-Za-z0-9+/]+={0,2}$/;

export async function POST(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to change your profile picture." }, { status: 401 });
    const input = await request.json() as { avatarUrl?: unknown };
    const avatarUrl = input.avatarUrl;
    if (avatarUrl !== null && (typeof avatarUrl !== "string" || avatarUrl.length > MAX_AVATAR_LENGTH || !AVATAR_DATA_URL.test(avatarUrl))) {
      return Response.json({ error: "Choose a smaller PNG, JPG, or WebP image." }, { status: 400 });
    }
    await getDb().update(chatUsers).set({ avatarUrl }).where(eq(chatUsers.id, account.id));
    return Response.json({ user: { id: account.id, username: account.username, avatarUrl } }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Your profile picture could not be saved. Try again." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
