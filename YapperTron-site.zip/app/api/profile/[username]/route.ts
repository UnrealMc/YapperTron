import { desc, eq, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { chatProfilePosts, chatProfiles, chatUsers } from "@/db/schema";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
let profileTablesReady: Promise<void> | null = null;

async function ensureProfileTables() {
  if (!profileTablesReady) {
    profileTablesReady = (async () => {
      const db = getDb();
      await db.run(sql`CREATE TABLE IF NOT EXISTS chat_profiles (
        user_id INTEGER PRIMARY KEY REFERENCES chat_users(id) ON DELETE CASCADE,
        display_name TEXT,
        bio TEXT NOT NULL DEFAULT '',
        theme_color TEXT NOT NULL DEFAULT '#d52f40'
      )`);
      await db.run(sql`CREATE TABLE IF NOT EXISTS chat_profile_posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL REFERENCES chat_users(id) ON DELETE CASCADE,
        text TEXT NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000)
      )`);
    })().catch((error) => {
      profileTablesReady = null;
      throw error;
    });
  }
  await profileTablesReady;
}

type Context = { params: Promise<{ username: string }> };

async function findAccount(username: string) {
  const key = decodeURIComponent(username).trim().toLocaleLowerCase("en-US");
  if (!key || key.length > 20) return null;
  const [user] = await getDb().select({ id: chatUsers.id, username: chatUsers.username, avatarUrl: chatUsers.avatarUrl,
    displayName: chatProfiles.displayName, bio: chatProfiles.bio, themeColor: chatProfiles.themeColor })
    .from(chatUsers).leftJoin(chatProfiles, eq(chatProfiles.userId, chatUsers.id)).where(eq(chatUsers.usernameKey, key)).limit(1);
  return user ?? null;
}

export async function GET(request: Request, context: Context) {
  try {
    if (!await getChatAccount(request)) return Response.json({ error: "Sign in to view profiles." }, { status: 401, headers: { "Cache-Control": "no-store" } });
    await ensureProfileTables();
    const { username } = await context.params;
    const profile = await findAccount(username);
    if (!profile) return Response.json({ error: "That account could not be found." }, { status: 404, headers: { "Cache-Control": "no-store" } });
    const posts = await getDb().select({ id: chatProfilePosts.id, text: chatProfilePosts.text, createdAt: chatProfilePosts.createdAt })
      .from(chatProfilePosts).where(eq(chatProfilePosts.userId, profile.id)).orderBy(desc(chatProfilePosts.createdAt)).limit(50);
    return Response.json({ profile: { ...profile, displayName: profile.displayName || profile.username }, posts }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "This profile is temporarily unavailable." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}

export async function PATCH(request: Request, context: Context) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to edit your profile." }, { status: 401 });
    await ensureProfileTables();
    const { username } = await context.params;
    const profile = await findAccount(username);
    if (!profile) return Response.json({ error: "That account could not be found." }, { status: 404 });
    if (profile.id !== account.id) return Response.json({ error: "You can only edit your own profile." }, { status: 403 });
    const input = await request.json() as { displayName?: unknown; bio?: unknown; themeColor?: unknown };
    const displayName = typeof input.displayName === "string" ? input.displayName.trim() : "";
    const bio = typeof input.bio === "string" ? input.bio.trim() : "";
    const themeColor = typeof input.themeColor === "string" ? input.themeColor : "#d52f40";
    if (displayName.length > 30 || bio.length > 180 || !/^#[0-9a-f]{6}$/i.test(themeColor)) {
      return Response.json({ error: "Name must be 30 characters or less, bio 180 or less, and color must be a hex color." }, { status: 400 });
    }
    await getDb().insert(chatProfiles).values({ userId: account.id, displayName: displayName || null, bio, themeColor })
      .onConflictDoUpdate({ target: chatProfiles.userId, set: { displayName: displayName || null, bio, themeColor } });
    return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Your profile changes could not be saved." }, { status: 503 });
  }
}

export async function POST(request: Request, context: Context) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to post on your profile." }, { status: 401 });
    await ensureProfileTables();
    const { username } = await context.params;
    const profile = await findAccount(username);
    if (!profile) return Response.json({ error: "That account could not be found." }, { status: 404 });
    if (profile.id !== account.id) return Response.json({ error: "You can only post on your own profile." }, { status: 403 });
    const input = await request.json() as { text?: unknown };
    const text = typeof input.text === "string" ? input.text.trim() : "";
    if (!text || text.length > 500) return Response.json({ error: "Write a post between 1 and 500 characters." }, { status: 400 });
    const [post] = await getDb().insert(chatProfilePosts).values({ userId: account.id, text }).returning({ id: chatProfilePosts.id, text: chatProfilePosts.text, createdAt: chatProfilePosts.createdAt });
    return Response.json({ post }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Your post could not be published." }, { status: 503 });
  }
}
