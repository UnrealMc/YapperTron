import { and, asc, desc, eq, gt, inArray, sql } from "drizzle-orm";
import { getDb } from "@/db";
import { chatUsers, messageReactions, messages } from "@/db/schema";
import { hashChatOwnerToken } from "@/lib/chat-owner";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Chat-Owner-Token",
  "Cache-Control": "no-store",
};

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: cors });
}

export async function GET(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const db = getDb();
    const ownerTokenHash = await hashChatOwnerToken(request.headers.get("X-Chat-Owner-Token"));
    const ownerReactionKeys = [`account:${account.id}`, ...(ownerTokenHash ? [`owner:${ownerTokenHash}`] : [])];
    const afterValue = Number(new URL(request.url).searchParams.get("after") ?? 0);
    const after = Number.isSafeInteger(afterValue) && afterValue > 0 ? afterValue : 0;
    const rows = after
      ? await db.select().from(messages).where(and(gt(messages.id, after), eq(messages.deleted, false))).orderBy(asc(messages.id)).limit(100)
      : (await db.select().from(messages).where(eq(messages.deleted, false)).orderBy(desc(messages.id)).limit(100)).reverse();
    const recentStateRows = await db.select({ id: messages.id, deleted: messages.deleted }).from(messages).orderBy(desc(messages.id)).limit(200);
    const deletedMessageIds = recentStateRows.filter((row) => row.deleted).map((row) => row.id);
    const recentIds = recentStateRows.filter((row) => !row.deleted).map((row) => row.id);
    const reactionRows = recentIds.length
      ? await db.select().from(messageReactions).where(inArray(messageReactions.messageId, recentIds))
      : [];
    const groupedReactions: Record<number, Array<{ emoji: string; names: string[]; mine: boolean }>> = {};
    for (const reaction of reactionRows) {
      const messageReactionsForId = groupedReactions[reaction.messageId] ??= [];
      let group = messageReactionsForId.find((item) => item.emoji === reaction.emoji);
      if (!group) {
        group = { emoji: reaction.emoji, names: [], mine: false };
        messageReactionsForId.push(group);
      }
      if (!group.names.includes(reaction.name)) group.names.push(reaction.name);
      if (ownerReactionKeys.includes(reaction.nameKey)) group.mine = true;
    }
    const replyIds = Array.from(new Set(rows.map((row) => row.replyTo).filter((id): id is number => id !== null)));
    const replyRows = replyIds.length
      ? await db.select({ id: messages.id, name: messages.name, text: messages.text }).from(messages).where(and(inArray(messages.id, replyIds), eq(messages.deleted, false)))
      : [];
    const replyById = new Map(replyRows.map((row) => [row.id, row]));
    const authorIds = Array.from(new Set(rows.map((row) => row.ownerUserId).filter((id): id is number => id !== null)));
    const authorRows = authorIds.length
      ? await db.select({ id: chatUsers.id, avatarUrl: chatUsers.avatarUrl }).from(chatUsers).where(inArray(chatUsers.id, authorIds))
      : [];
    const avatarByUserId = new Map(authorRows.map((row) => [row.id, row.avatarUrl]));
    const hydratedMessages = rows.map((row) => {
      const { ownerTokenHash: _ownerTokenHash, ownerUserId: _ownerUserId, ...message } = row;
      return {
        ...message,
        avatarUrl: row.ownerUserId === null ? null : avatarByUserId.get(row.ownerUserId) ?? null,
        reactions: groupedReactions[row.id] ?? [],
        reply: row.replyTo === null ? null : replyById.get(row.replyTo) ?? null,
        isMine: row.ownerUserId === account.id || Boolean(ownerTokenHash && row.ownerTokenHash === ownerTokenHash),
      };
    });
    const editedSnapshot = await db.select({ id: messages.id, text: messages.text, edited: messages.edited })
      .from(messages).where(and(eq(messages.edited, true), eq(messages.deleted, false))).orderBy(desc(messages.id)).limit(200);
    return Response.json({ messages: hydratedMessages, reactionSnapshot: groupedReactions, editedSnapshot, deletedMessageIds }, { headers: cors });
  } catch {
    return Response.json({ error: "Chat is temporarily unavailable." }, { status: 503, headers: cors });
  }
}

export async function POST(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const input = await request.json() as { text?: unknown; replyTo?: unknown; ownerToken?: unknown };
    const name = account.username;
    const text = typeof input.text === "string" ? input.text.trim() : "";
    const ownerTokenHash = await hashChatOwnerToken(input.ownerToken);
    if (!text || !ownerTokenHash) return Response.json({ error: "Message and owner token are required." }, { status: 400, headers: cors });
    if (text.startsWith("FILE|")) {
      if (text.length > 400_000) return Response.json({ error: "That file is too large to share." }, { status: 413, headers: cors });
      try {
        const file = JSON.parse(text.slice(5)) as { name?: unknown; type?: unknown; dataUrl?: unknown };
        if (typeof file.name !== "string" || !file.name.trim() || file.name.length > 180 ||
            typeof file.type !== "string" || file.type.length > 120 ||
            typeof file.dataUrl !== "string" || file.dataUrl.length > 380_000 ||
            !file.dataUrl.startsWith(`data:${file.type};base64,`)) {
          return Response.json({ error: "That file could not be shared." }, { status: 400, headers: cors });
        }
      } catch {
        return Response.json({ error: "That file could not be shared." }, { status: 400, headers: cors });
      }
    } else if (text.length > 1000) {
      return Response.json({ error: "Messages must be 1,000 characters or less." }, { status: 413, headers: cors });
    }

    const db = getDb();
    let replyTo: number | null = null;
    if (input.replyTo !== undefined && input.replyTo !== null) {
      if (typeof input.replyTo !== "number" || !Number.isSafeInteger(input.replyTo) || input.replyTo <= 0) {
        return Response.json({ error: "That reply could not be sent." }, { status: 400, headers: cors });
      }
      const [parent] = await db.select({ id: messages.id }).from(messages).where(and(eq(messages.id, input.replyTo), eq(messages.deleted, false))).limit(1);
      if (!parent) return Response.json({ error: "The message you replied to is no longer available." }, { status: 404, headers: cors });
      replyTo = parent.id;
    }
    const [message] = await db.insert(messages).values({ name, text, replyTo, ownerTokenHash, ownerUserId: account.id }).returning({
      id: messages.id,
      name: messages.name,
      text: messages.text,
      createdAt: messages.createdAt,
      replyTo: messages.replyTo,
      edited: messages.edited,
      deleted: messages.deleted,
    });
    await db.run(sql`DELETE FROM messages WHERE id NOT IN (SELECT id FROM messages ORDER BY id DESC LIMIT 200)`);
    return Response.json({ ok: true, message: { ...message, reactions: [], reply: null, isMine: true } }, { headers: cors });
  } catch {
    return Response.json({ error: "Message could not be sent." }, { status: 503, headers: cors });
  }
}
