import { and, eq, or } from "drizzle-orm";
import { getDb } from "@/db";
import { messageReactions, messages } from "@/db/schema";
import { hashChatOwnerToken } from "@/lib/chat-owner";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store",
};

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: cors });
}

export async function POST(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const input = await request.json() as {
      action?: unknown;
      messageId?: unknown;
      ownerToken?: unknown;
      text?: unknown;
    };
    const ownerTokenHash = await hashChatOwnerToken(input.ownerToken);
    const messageId = input.messageId;
    if (typeof messageId !== "number" || !Number.isSafeInteger(messageId) || messageId <= 0 ||
        (input.action !== "edit" && input.action !== "delete")) {
      return Response.json({ error: "That message action is not valid." }, { status: 400, headers: cors });
    }

    const db = getDb();
    const ownership = or(eq(messages.ownerUserId, account.id), ...(ownerTokenHash ? [eq(messages.ownerTokenHash, ownerTokenHash)] : []));
    const [ownedMessage] = await db.select({ text: messages.text })
      .from(messages)
      .where(and(eq(messages.id, messageId), eq(messages.deleted, false), ownership))
      .limit(1);
    if (!ownedMessage) return Response.json({ error: "You can only change your own messages." }, { status: 403, headers: cors });

    if (input.action === "edit") {
      const text = typeof input.text === "string" ? input.text.trim() : "";
      if (!text || text.length > 1000 || /^(FILE\||GIF\||STICKER\|)/.test(ownedMessage.text)) {
        return Response.json({ error: "Only text messages up to 1,000 characters can be edited." }, { status: 400, headers: cors });
      }
      const [updated] = await db.update(messages)
        .set({ text, edited: true })
        .where(and(eq(messages.id, messageId), eq(messages.deleted, false), ownership))
        .returning({ id: messages.id, text: messages.text, edited: messages.edited });
      return Response.json({ ok: true, message: updated }, { headers: cors });
    }

    await db.update(messages)
      .set({ text: "", replyTo: null, ownerTokenHash: null, ownerUserId: null, deleted: true })
      .where(and(eq(messages.id, messageId), eq(messages.deleted, false), ownership));
    await db.delete(messageReactions).where(eq(messageReactions.messageId, messageId));
    return Response.json({ ok: true, messageId, deleted: true }, { headers: cors });
  } catch {
    return Response.json({ error: "That message could not be updated." }, { status: 503, headers: cors });
  }
}
