import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { chatAuthAttempts, chatUsers } from "@/db/schema";
import { constantTimeEqual, createSession, derivePasswordHash, sessionCookie, sha256, SESSION_AGE_SECONDS, SESSION_ONLY_AGE_SECONDS } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 8;

export async function POST(request: Request) {
  try {
    const input = await request.json() as { username?: unknown; password?: unknown; rememberMe?: unknown };
    const rememberMe = input.rememberMe === true;
    const username = typeof input.username === "string" ? input.username.trim() : "";
    const password = typeof input.password === "string" ? input.password : "";
    if (!username || username.length > 20 || !password || password.length > 128) {
      return Response.json({ error: "Username or password is incorrect." }, { status: 401 });
    }

    const db = getDb();
    const usernameKey = username.toLocaleLowerCase("en-US");
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    const attemptKey = await sha256(`${ip}:${usernameKey}`);
    const now = new Date();
    const [attempt] = await db.select().from(chatAuthAttempts).where(eq(chatAuthAttempts.attemptKey, attemptKey)).limit(1);
    if (attempt && now.getTime() - attempt.windowStartedAt.getTime() < LOGIN_WINDOW_MS && attempt.attempts >= MAX_ATTEMPTS) {
      return Response.json({ error: "Too many sign-in attempts. Wait 15 minutes and try again." }, { status: 429 });
    }

    const [user] = await db.select().from(chatUsers).where(eq(chatUsers.usernameKey, usernameKey)).limit(1);
    const candidateHash = await derivePasswordHash(password, user?.passwordSalt ?? "yappertron-login-check-salt");
    if (!user || !constantTimeEqual(candidateHash, user.passwordHash)) {
      if (!attempt) await db.insert(chatAuthAttempts).values({ attemptKey, attempts: 1, windowStartedAt: now });
      else if (now.getTime() - attempt.windowStartedAt.getTime() >= LOGIN_WINDOW_MS) {
        await db.update(chatAuthAttempts).set({ attempts: 1, windowStartedAt: now }).where(eq(chatAuthAttempts.attemptKey, attemptKey));
      } else {
        await db.update(chatAuthAttempts).set({ attempts: attempt.attempts + 1 }).where(eq(chatAuthAttempts.attemptKey, attemptKey));
      }
      return Response.json({ error: "Username or password is incorrect." }, { status: 401 });
    }

    await db.delete(chatAuthAttempts).where(eq(chatAuthAttempts.attemptKey, attemptKey));
    const maxAge = rememberMe ? SESSION_AGE_SECONDS : SESSION_ONLY_AGE_SECONDS;
    const token = await createSession(user.id, maxAge);
    return Response.json({ user: { id: user.id, username: user.username, avatarUrl: user.avatarUrl } }, { headers: { "Set-Cookie": sessionCookie(token, rememberMe ? SESSION_AGE_SECONDS : undefined), "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("YapperTron sign-in failed", error instanceof Error ? { name: error.name, message: error.message } : { name: "UnknownError" });
    return Response.json({ error: "Could not sign in right now. Try again." }, { status: 503 });
  }
}
