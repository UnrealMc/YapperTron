import { destroySession, sessionCookie } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    await destroySession(request);
    return Response.json({ ok: true }, { headers: { "Set-Cookie": sessionCookie("", 0), "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Could not sign out right now." }, { status: 503 });
  }
}
