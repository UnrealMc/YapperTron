import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { chatAuthAttempts, chatUsers } from "@/db/schema";
import { createSession, derivePasswordHash, randomHex, sessionCookie, sha256, SESSION_AGE_SECONDS, SESSION_ONLY_AGE_SECONDS } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const input = await request.json() as { username?: unknown; password?: unknown; rememberMe?: unknown };
    const rememberMe = input.rememberMe === true;
    const username = typeof input.username === "string" ? input.username.trim() : "";
    const password = typeof input.password === "string" ? input.password : "";
    if (!/^[A-Za-z0-9_.-]{3,20}$/.test(username)) {
      return Response.json({ error: "Username must be 3–20 characters using letters, numbers, dots, dashes, or underscores." }, { status: 400 });
    }
    if (password.length < 8 || password.length > 128) {
      return Response.json({ error: "Password must be between 8 and 128 characters." }, { status: 400 });
    }

    const db = getDb();
    const now = new Date();
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    const attemptKey = await sha256(`register:v2:${ip}`);
    const [attempt] = await db.select().from(chatAuthAttempts).where(eq(chatAuthAttempts.attemptKey, attemptKey)).limit(1);
    const registrationWindowMs = 60 * 60 * 1000;
    if (attempt && now.getTime() - attempt.windowStartedAt.getTime() < registrationWindowMs && attempt.attempts >= 50) {
      return Response.json({ error: "Too many accounts created from this connection. Try again later." }, { status: 429 });
    }
    if (!attempt) await db.insert(chatAuthAttempts).values({ attemptKey, attempts: 1, windowStartedAt: now });
    else if (now.getTime() - attempt.windowStartedAt.getTime() >= registrationWindowMs) {
      await db.update(chatAuthAttempts).set({ attempts: 1, windowStartedAt: now }).where(eq(chatAuthAttempts.attemptKey, attemptKey));
    } else {
      await db.update(chatAuthAttempts).set({ attempts: attempt.attempts + 1 }).where(eq(chatAuthAttempts.attemptKey, attemptKey));
    }
    const usernameKey = username.toLocaleLowerCase("en-US");
    const [existing] = await db.select({ id: chatUsers.id }).from(chatUsers).where(eq(chatUsers.usernameKey, usernameKey)).limit(1);
    if (existing) return Response.json({ error: "That username is already taken. Try another one." }, { status: 409 });

    const passwordSalt = randomHex(16);
    const passwordHash = await derivePasswordHash(password, passwordSalt);
    // Avoid relying on D1's INSERT ... RETURNING response when provisioning the session.
    await db.insert(chatUsers).values({ username, usernameKey, passwordHash, passwordSalt });
    const [user] = await db.select({ id: chatUsers.id, username: chatUsers.username, avatarUrl: chatUsers.avatarUrl }).from(chatUsers).where(eq(chatUsers.usernameKey, usernameKey)).limit(1);
    if (!user) throw new Error("New account could not be loaded after creation.");
    const maxAge = rememberMe ? SESSION_AGE_SECONDS : SESSION_ONLY_AGE_SECONDS;
    const token = await createSession(user.id, maxAge);
    return Response.json({ user }, { headers: { "Set-Cookie": sessionCookie(token, rememberMe ? SESSION_AGE_SECONDS : undefined), "Cache-Control": "no-store" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (/chat_users_username_key_unique|chat_users\.username_key|UNIQUE constraint failed/i.test(message)) {
      return Response.json({ error: "That username is already taken. Try another one." }, { status: 409 });
    }
    console.error("YapperTron registration failed", error instanceof Error ? { name: error.name, message: error.message } : { name: "UnknownError" });
    return Response.json({ error: "Account could not be created. Try again." }, { status: 503 });
  }
}
