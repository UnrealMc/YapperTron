import { eq } from "drizzle-orm";
import { getDb } from "@/db";
import { chatUsers } from "@/db/schema";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const user = await getChatAccount(request);
    if (!user) return Response.json({ user: null }, { headers: { "Cache-Control": "no-store" } });
    const [profile] = await getDb().select({ avatarUrl: chatUsers.avatarUrl }).from(chatUsers).where(eq(chatUsers.id, user.id)).limit(1);
    return Response.json({ user: { ...user, avatarUrl: profile?.avatarUrl ?? null } }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Could not load your account." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
