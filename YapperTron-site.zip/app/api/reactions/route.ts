import { and, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { messageReactions, messages } from "@/db/schema";
import { hashChatOwnerToken } from "@/lib/chat-owner";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Chat-Owner-Token",
  "Cache-Control": "no-store",
};

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: cors });
}

export async function POST(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const input = await request.json() as { messageId?: unknown; emoji?: unknown; ownerToken?: unknown };
    const messageId = input.messageId;
    const name = account.username;
    const emoji = typeof input.emoji === "string" ? input.emoji.trim() : "";
    const ownerTokenHash = await hashChatOwnerToken(input.ownerToken);
    if (typeof messageId !== "number" || !Number.isSafeInteger(messageId) || messageId <= 0 ||
        !emoji || emoji.length > 12 || /[\u0000-\u001f|]/.test(emoji)) {
      return Response.json({ error: "Choose a valid reaction." }, { status: 400, headers: cors });
    }

    const db = getDb();
    const [target] = await db.select({ id: messages.id }).from(messages)
      .where(and(eq(messages.id, messageId), eq(messages.deleted, false))).limit(1);
    if (!target) return Response.json({ error: "That message is no longer available." }, { status: 404, headers: cors });

    const nameKey = `account:${account.id}`;
    const conditions = and(
      eq(messageReactions.messageId, messageId),
      eq(messageReactions.nameKey, nameKey),
      eq(messageReactions.emoji, emoji),
    );
    const [existing] = await db.select({ messageId: messageReactions.messageId, name: messageReactions.name })
      .from(messageReactions).where(conditions).limit(1);
    let removed = false;
    let removedName: string | null = null;
    if (existing) {
      await db.delete(messageReactions).where(conditions);
      removed = true;
      removedName = existing.name;
    } else {
      const oldKeys = [
        ...(ownerTokenHash ? [`owner:${ownerTokenHash}`] : []),
        name.toLocaleLowerCase(),
      ];
      let legacy = null as { messageId: number; name: string; nameKey: string } | null;
      for (const oldKey of oldKeys) {
        const [candidate] = await db.select({ messageId: messageReactions.messageId, name: messageReactions.name, nameKey: messageReactions.nameKey })
          .from(messageReactions).where(and(eq(messageReactions.messageId, messageId), eq(messageReactions.nameKey, oldKey), eq(messageReactions.emoji, emoji))).limit(1);
        if (candidate) { legacy = candidate; break; }
      }
      if (legacy) {
        await db.delete(messageReactions).where(and(eq(messageReactions.messageId, messageId), eq(messageReactions.nameKey, legacy.nameKey), eq(messageReactions.emoji, emoji)));
        removed = true;
        removedName = legacy.name;
      } else {
        await db.insert(messageReactions).values({ messageId, nameKey, name, emoji });
      }
    }
    return Response.json({ ok: true, active: !removed, name: removedName ?? name }, { headers: cors });
  } catch {
    return Response.json({ error: "Reaction could not be saved." }, { status: 503, headers: cors });
  }
}
