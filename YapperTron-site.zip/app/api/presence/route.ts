import { asc, inArray } from "drizzle-orm";
import { getDb } from "@/db";
import { chatUsers, members, messages } from "@/db/schema";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store",
};
const ONLINE_FOR_MS = 45_000;

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: cors });
}

export async function GET(request: Request) {
  try {
    if (!await getChatAccount(request)) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const now = Date.now();
    const db = getDb();
    const [rows, chatters] = await Promise.all([
      db.select().from(members).orderBy(asc(members.name)),
      db.selectDistinct({ name: messages.name }).from(messages),
    ]);
    const everyone = new Map(rows.map((member) => [member.nameKey, {
      name: member.name,
      online: now - member.lastSeen.getTime() < ONLINE_FOR_MS,
    }]));
    for (const chatter of chatters) {
      const key = chatter.name.toLocaleLowerCase();
      if (!everyone.has(key)) everyone.set(key, { name: chatter.name, online: false });
    }
    const names = Array.from(everyone.keys());
    const profiles = names.length
      ? await db.select({ usernameKey: chatUsers.usernameKey, avatarUrl: chatUsers.avatarUrl }).from(chatUsers).where(inArray(chatUsers.usernameKey, names))
      : [];
    const avatarByName = new Map(profiles.map((profile) => [profile.usernameKey, profile.avatarUrl]));
    const result = Array.from(everyone.entries())
      .map(([nameKey, member]) => ({ ...member, avatarUrl: avatarByName.get(nameKey) ?? null }))
      .sort((a, b) => a.name.localeCompare(b.name));
    return Response.json({ members: result }, { headers: cors });
  } catch {
    return Response.json({ error: "Member list is temporarily unavailable." }, { status: 503, headers: cors });
  }
}

export async function POST(request: Request) {
  try {
    const account = await getChatAccount(request);
    if (!account) return Response.json({ error: "Sign in to use YapperTron." }, { status: 401, headers: cors });
    const name = account.username;
    await getDb().insert(members).values({
      nameKey: name.toLocaleLowerCase(),
      name,
      lastSeen: new Date(),
    }).onConflictDoUpdate({
      target: members.nameKey,
      set: { name, lastSeen: new Date() },
    });
    return Response.json({ ok: true }, { headers: cors });
  } catch {
    return Response.json({ error: "Presence could not be updated." }, { status: 503, headers: cors });
  }
}
