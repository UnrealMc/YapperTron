import { asc, like } from "drizzle-orm";
import { getDb } from "@/db";
import { chatUsers } from "@/db/schema";
import { getChatAccount } from "@/lib/chat-sessions";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    if (!await getChatAccount(request)) return Response.json({ error: "Sign in to search accounts." }, { status: 401, headers: { "Cache-Control": "no-store" } });
    const query = new URL(request.url).searchParams.get("q")?.trim().slice(0, 20) ?? "";
    if (!query) return Response.json({ accounts: [] }, { headers: { "Cache-Control": "no-store" } });
    const accounts = await getDb().select({ username: chatUsers.username, avatarUrl: chatUsers.avatarUrl })
      .from(chatUsers).where(like(chatUsers.usernameKey, `%${query.toLocaleLowerCase("en-US")}%`))
      .orderBy(asc(chatUsers.usernameKey)).limit(8);
    return Response.json({ accounts }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Account search is temporarily unavailable." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
